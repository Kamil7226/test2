"""
Modele obiektowe projektu CineStream – Krok Milowy Tygodnia 5.
Encja MediaTitle oraz agregat Watchlist.
"""

from __future__ import annotations
from typing import Any


class MediaTitle:
    """Pojedynczy film/serial w katalogu CineStream."""

    def __init__(
        self,
        title_id: int,
        title: str,
        year: int,
        rating: float | None,
        genre: str,
        is_watched: bool,
        duration_min: int,
    ) -> None:
        self._title_id = title_id
        self.title = title
        self.year = year
        self.genre = genre
        self._is_watched = is_watched
        self._rating: float | None = None
        self.duration_min = duration_min

        # Ocena jest ustawiana dopiero po ustawieniu statusu obejrzenia.
        if rating is not None:
            self.rating = rating

    @property
    def title_id(self) -> int:
        """Identyfikator jest niemutowalny."""
        return self._title_id

    @property
    def is_watched(self) -> bool:
        return self._is_watched

    @is_watched.setter
    def is_watched(self, value: bool) -> None:
        if not isinstance(value, bool):
            raise TypeError("is_watched musi mieć wartość bool.")
        self._is_watched = value
        if not value:
            self._rating = None

    @property
    def rating(self) -> float | None:
        return self._rating

    @rating.setter
    def rating(self, value: float | None) -> None:
        if value is None:
            self._rating = None
            return
        if not self._is_watched:
            raise ValueError("Ocena może być przypisana wyłącznie obejrzanemu tytułowi.")
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError("Ocena musi być liczbą.")
        if not 1.0 <= float(value) <= 10.0:
            raise ValueError("Ocena musi mieścić się w przedziale 1.0–10.0.")
        self._rating = round(float(value), 1)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, MediaTitle):
            return False
        return self.title_id == other.title_id

    def __lt__(self, other: MediaTitle) -> bool:
        """Sortowanie od najwyższej oceny; nieocenione tytuły trafiają na koniec."""
        if not isinstance(other, MediaTitle):
            return NotImplemented
        self_rating = self.rating if self.rating is not None else 0.0
        other_rating = other.rating if other.rating is not None else 0.0
        return (-self_rating, self.title.casefold()) < (
            -other_rating, other.title.casefold()
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "title_id": self.title_id,
            "title": self.title,
            "year": self.year,
            "rating": self.rating,
            "genre": self.genre,
            "is_watched": self.is_watched,
            "duration_min": self.duration_min,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MediaTitle:
        return cls(
            title_id=int(data["title_id"]),
            title=str(data["title"]),
            year=int(data["year"]),
            rating=data.get("rating"),
            genre=str(data["genre"]),
            is_watched=bool(data["is_watched"]),
            duration_min=int(data["duration_min"]),
        )

    def __repr__(self) -> str:
        return (
            f"MediaTitle(title_id={self.title_id}, title={self.title!r}, "
            f"year={self.year}, rating={self.rating!r}, genre={self.genre!r}, "
            f"is_watched={self.is_watched}, duration_min={self.duration_min})"
        )

    def __str__(self) -> str:
        rating_text = f"{self.rating:.1f}/10" if self.rating is not None else "brak"
        status = "obejrzany" if self.is_watched else "nieobejrzany"
        return (
            f"[{self.title_id:03d}] {self.title} ({self.year}) | "
            f"{self.genre} | {self.duration_min} min | "
            f"Ocena: {rating_text} | {status}"
        )


class Watchlist:
    """Agregat zarządzający kolekcją obiektów MediaTitle."""

    def __init__(self, watchlist_id: int, name: str, titles: list[MediaTitle] | None = None) -> None:
        self.watchlist_id = watchlist_id
        self.name = name
        self._titles: list[MediaTitle] = []
        for title in titles or []:
            self.add_title(title)

    @property
    def titles(self) -> list[MediaTitle]:
        """Zwraca kopię listy, aby chronić kolekcję przed modyfikacją z zewnątrz."""
        return list(self._titles)

    def add_title(self, title: MediaTitle) -> None:
        if not isinstance(title, MediaTitle):
            raise TypeError("Watchlist może zawierać wyłącznie obiekty MediaTitle.")
        if title in self._titles:
            raise ValueError("Ten tytuł znajduje się już na liście.")
        self._titles.append(title)

    def remove_title(self, title_id: int) -> bool:
        for title in self._titles:
            if title.title_id == title_id:
                self._titles.remove(title)
                return True
        return False

    def total_runtime_hours(self) -> float:
        return round(sum(title.duration_min for title in self._titles) / 60.0, 2)

    def to_dict(self) -> dict[str, Any]:
        return {
            "watchlist_id": self.watchlist_id,
            "name": self.name,
            "titles": [title.to_dict() for title in self._titles],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Watchlist:
        titles = [MediaTitle.from_dict(raw) for raw in data.get("titles", [])]
        return cls(
            watchlist_id=int(data["watchlist_id"]),
            name=str(data["name"]),
            titles=titles,
        )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Watchlist):
            return False
        return self.to_dict() == other.to_dict()

    def __str__(self) -> str:
        lines = [f"=== {self.name} (lista #{self.watchlist_id}) ==="]
        lines.extend(str(title) for title in self._titles)
        lines.append(f"Łączny czas: {self.total_runtime_hours():.2f} godz.")
        return "\\n".join(lines)
