# CineStream – Krok Milowy Tygodnia 5

To jest implementacja dla zespołu 1 (CineStream) z materiału Laboratorium 3.1.

## Pliki
- `models.py` – encja `MediaTitle` i agregat `Watchlist`.
- `test_models.py` – cztery wymagane scenariusze autotestów.

## Uruchomienie
Umieść oba pliki w katalogu `src` obok pozostałych modułów projektu, a następnie w terminalu:
```bash
python test_models.py
```

Oczekiwany wynik:
```text
[OK] test_poprawne_instancjonowanie
[OK] test_odrzucenie_blednych_danych
[OK] test_sortowanie_lt
[OK] test_serializacja_round_trip

Wszystkie 4 scenariusze testowe zakończone powodzeniem.
```

## Zasady z zadania
- `MediaTitle`: `title_id`, `title`, `year`, `rating`, `genre`, `is_watched`, `duration_min`.
- Ocena 1.0–10.0 jest możliwa wyłącznie dla obejrzanego tytułu.
- `Watchlist` zarządza kolekcją `MediaTitle` (kompozycja 1:N).
- `total_runtime_hours()` sumuje czas trwania w godzinach.
- `__lt__` sortuje tytuły malejąco według oceny.
- `to_dict()` i `from_dict()` zapewniają serializację i odtworzenie zagnieżdżonej struktury.
