"""Główny punkt wejścia do aplikacji CineStream."""
from storage import load_watchlist, save_watchlist, export_watchlist_to_csv
from validators import get_int_input
from services import display_movies, add_movie, filter_movies_by_genre, sort_movies


def print_menu() -> None:
    print("\n" + "=" * 48)
    print("          CINESTREAM - MENADŻER VOD")
    print("=" * 48)
    print("1. Wyświetl katalog filmów")
    print("2. Dodaj nowy film")
    print("3. Filtruj filmy po gatunku")
    print("4. Eksportuj katalog do CSV")
    print("5. Sortuj filmy według oceny")
    print("6. Wyjście z programu")
    print("-" * 48)


def main() -> None:
    watchlist = load_watchlist()
    running = True

    while running:
        print_menu()
        choice = get_int_input("Wybierz opcję [1-6]: ", 1, 6)

        try:
            if choice == 1:
                display_movies(watchlist)
            elif choice == 2:
                add_movie(watchlist)
                save_watchlist(watchlist)
            elif choice == 3:
                filter_movies_by_genre(watchlist)
            elif choice == 4:
                count = export_watchlist_to_csv(watchlist)
                print(f"\n[Sukces] Wyeksportowano {count} filmów do exports/watchlist.csv.")
            elif choice == 5:
                sort_movies(watchlist)
            elif choice == 6:
                save_watchlist(watchlist)
                print("\nZamykanie CineStream. Do widzenia!")
                running = False
        except (ValueError, TypeError) as error:
            print(f"\n[Błąd danych] {error}")


if __name__ == "__main__":
    main()
