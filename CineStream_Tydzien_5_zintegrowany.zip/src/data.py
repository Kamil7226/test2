"""Dane początkowe aplikacji CineStream."""
from models import MediaTitle, Watchlist

DEFAULT_WATCHLIST = Watchlist(
    1,
    "Katalog CineStream",
    [
        MediaTitle(1, "Incepcja", 2010, 8.8, "Sci-Fi", True, 148),
        MediaTitle(2, "Skazani na Shawshank", 1994, 9.3, "Dramat", True, 142),
        MediaTitle(3, "Interstellar", 2014, 8.7, "Sci-Fi", True, 169),
        MediaTitle(4, "Shrek", 2001, None, "Animacja", False, 90),
        MediaTitle(5, "Shrek 2", 2004, None, "Animacja", False, 93),
        MediaTitle(6, "Odyseja", 2026, None, "Dramat", False, 150),
    ],
)
