"""Zapis i odczyt katalogu CineStream w formacie JSON oraz eksport CSV."""
import csv
import json
import os
import shutil
import tempfile
from datetime import datetime
from pathlib import Path

from data import DEFAULT_WATCHLIST
from models import Watchlist

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
EXPORTS_DIR = BASE_DIR / "exports"
CATALOG_FILE = DATA_DIR / "watchlist.json"


def create_backup(source_file: Path, max_backups: int = 3) -> Path | None:
    if not source_file.exists():
        return None
    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup_path = backup_dir / f"{source_file.stem}_{stamp}.bak"
    shutil.copy2(source_file, backup_path)
    backups = sorted(backup_dir.glob(f"{source_file.stem}_*.bak"))
    while len(backups) > max_backups:
        backups.pop(0).unlink(missing_ok=True)
    return backup_path


def save_watchlist(watchlist: Watchlist) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if CATALOG_FILE.exists():
        create_backup(CATALOG_FILE)
    temp_name = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=DATA_DIR,
            prefix="watchlist_tmp_", suffix=".json", delete=False
        ) as tmp:
            json.dump(watchlist.to_dict(), tmp, indent=4, ensure_ascii=False)
            tmp.flush()
            os.fsync(tmp.fileno())
            temp_name = tmp.name
        os.replace(temp_name, CATALOG_FILE)
    finally:
        if temp_name and os.path.exists(temp_name):
            os.unlink(temp_name)


def load_watchlist() -> Watchlist:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    try:
        with CATALOG_FILE.open("r", encoding="utf-8") as file:
            return Watchlist.from_dict(json.load(file))
    except FileNotFoundError:
        watchlist = Watchlist.from_dict(DEFAULT_WATCHLIST.to_dict())
        save_watchlist(watchlist)
        return watchlist
    except (json.JSONDecodeError, KeyError, TypeError, ValueError) as error:
        print(f"[OSTRZEŻENIE] Nie można odczytać bazy ({error}). Wczytano dane domyślne.")
        return Watchlist.from_dict(DEFAULT_WATCHLIST.to_dict())


def export_watchlist_to_csv(watchlist: Watchlist) -> int:
    EXPORTS_DIR.mkdir(parents=True, exist_ok=True)
    path = EXPORTS_DIR / "watchlist.csv"
    fields = [
        "title_id", "title", "year", "rating", "genre",
        "is_watched", "duration_min"
    ]
    with path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        for title in watchlist.titles:
            writer.writerow(title.to_dict())
    return len(watchlist.titles)
