"""Funkcje walidujące dane wprowadzane przez użytkownika."""


def get_int_input(prompt: str, min_val: int | None = None,
                  max_val: int | None = None) -> int:
    while True:
        raw = input(prompt).strip()
        try:
            value = int(raw)
            if min_val is not None and value < min_val:
                print(f"Wartość musi wynosić co najmniej {min_val}.")
                continue
            if max_val is not None and value > max_val:
                print(f"Wartość nie może przekraczać {max_val}.")
                continue
            return value
        except ValueError:
            print("Podaj poprawną liczbę całkowitą.")


def get_float_input(prompt: str, min_val: float | None = None,
                    max_val: float | None = None) -> float:
    while True:
        raw = input(prompt).strip().replace(",", ".")
        try:
            value = float(raw)
            if min_val is not None and value < min_val:
                print(f"Wartość musi wynosić co najmniej {min_val}.")
                continue
            if max_val is not None and value > max_val:
                print(f"Wartość nie może przekraczać {max_val}.")
                continue
            return value
        except ValueError:
            print("Podaj poprawną liczbę.")


def get_non_empty_string(prompt: str) -> str:
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("To pole nie może być puste.")


def get_yes_no(prompt: str) -> bool:
    while True:
        value = input(prompt).strip().lower()
        if value in ("t", "tak", "y", "yes"):
            return True
        if value in ("n", "nie", "no"):
            return False
        print("Wpisz tak lub nie.")
