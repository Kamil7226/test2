"""Logika operacji na katalogu CineStream."""
from models import MediaTitle, Watchlist
from validators import (
    get_float_input, get_int_input, get_non_empty_string, get_yes_no
)


def display_movies(watchlist: Watchlist) -> None:
    titles = watchlist.titles
    if not titles:
        print("\n[Informacja] Katalog jest pusty.")
        return

    print("\n" + "-" * 93)
    print(
        f"| {'ID':<3} | {'Tytuł filmu':<25} | {'Gatunek':<12} "
        f"| {'Rok':<4} | {'Ocena':<5} | {'Min':<5} | {'Obejrz.':<5} |"
    )
    print("-" * 93)
    for title in titles:
        print(title)
    print("-" * 93)
    print(f"Liczba pozycji: {len(titles)}")
    print(f"Łączny czas: {watchlist.total_runtime_hours():.2f} godz.\n")


def add_movie(watchlist: Watchlist) -> None:
    print("\n--- DODAWANIE FILMU ---")
    new_id = max((movie.title_id for movie in watchlist.titles), default=0) + 1
    title = get_non_empty_string("Podaj tytuł filmu: ")
    genre = get_non_empty_string("Podaj gatunek: ")
    year = get_int_input("Podaj rok premiery: ", 1888, 2100)
    duration = get_int_input("Podaj czas trwania w minutach: ", 1, 1000)
    watched = get_yes_no("Czy film został obejrzany? (tak/nie): ")
    rating = None
    if watched:
        rating = get_float_input("Podaj ocenę (1.0-10.0): ", 1.0, 10.0)

    movie = MediaTitle(new_id, title, year, rating, genre, watched, duration)
    watchlist.add_title(movie)
    print(f"\n[Sukces] Dodano film: {title} (ID: {new_id}).")


def filter_movies_by_genre(watchlist: Watchlist) -> None:
    if not watchlist.titles:
        print("\n[Informacja] Katalog jest pusty.")
        return
    genre = get_non_empty_string("Podaj gatunek do wyszukania: ").casefold()
    results = [movie for movie in watchlist.titles if genre in movie.genre.casefold()]
    if not results:
        print("\nNie znaleziono filmów dla podanego gatunku.")
        return
    print(f"\n--- Wyniki filtrowania: {genre} ---")
    for movie in results:
        print(movie)


def sort_movies(watchlist: Watchlist) -> None:
    sorted_titles = sorted(watchlist.titles)
    print("\n--- FILMY POSORTOWANE WG OCENY ---")
    for movie in sorted_titles:
        print(movie)
