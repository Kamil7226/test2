"""Autotesty Kroku Milowego Tygodnia 5. Uruchom: python test_models.py"""
from models import MediaTitle, Watchlist


def test_poprawne_instancjonowanie():
    movie = MediaTitle(1, "Incepcja", 2010, 8.8, "Sci-Fi", True, 148)
    watchlist = Watchlist(1, "Moje filmy", [movie])
    assert movie.title == "Incepcja"
    assert movie.rating == 8.8
    assert len(watchlist.titles) == 1
    assert watchlist.total_runtime_hours() == 2.47


def test_odrzucenie_blednych_danych():
    try:
        MediaTitle(2, "Film", 2020, 7.0, "Dramat", False, 100)
        assert False, "Ocena nieobejrzanego filmu powinna być odrzucona."
    except ValueError:
        pass

    movie = MediaTitle(3, "Film", 2020, None, "Dramat", True, 90)
    try:
        movie.rating = 11.0
        assert False, "Ocena powyżej 10 powinna być odrzucona."
    except ValueError:
        pass


def test_sortowanie_lt():
    movies = [
        MediaTitle(1, "Film A", 2020, 6.0, "Dramat", True, 100),
        MediaTitle(2, "Film B", 2021, 9.0, "Sci-Fi", True, 120),
        MediaTitle(3, "Film C", 2022, 8.0, "Komedia", True, 90),
    ]
    movies.sort()
    assert [movie.title for movie in movies] == ["Film B", "Film C", "Film A"]


def test_serializacja_round_trip():
    original = Watchlist(10, "Wieczorny seans", [
        MediaTitle(1, "Incepcja", 2010, 8.8, "Sci-Fi", True, 148),
        MediaTitle(2, "Shrek", 2001, None, "Animacja", False, 90),
    ])
    restored = Watchlist.from_dict(original.to_dict())
    assert original == restored


def run_tests():
    tests = [
        test_poprawne_instancjonowanie,
        test_odrzucenie_blednych_danych,
        test_sortowanie_lt,
        test_serializacja_round_trip,
    ]
    for test in tests:
        test()
        print(f"[OK] {test.__name__}")
    print("\nWszystkie 4 scenariusze testowe zakończone powodzeniem.")


if __name__ == "__main__":
    run_tests()
