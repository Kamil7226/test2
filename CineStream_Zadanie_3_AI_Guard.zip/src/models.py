"""
Modele domenowe CineStream – Zadanie 3.
Kontrakt abstrakcyjny MediaTitle oraz podklasy Movie i Series.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class MediaTitle(ABC):
    """Abstrakcyjny kontrakt wspólny dla filmów i seriali."""

    def __init__(
        self,
        title_id: int,
        title: str,
        year: int,
        genre: str,
        platform: str,
        is_watched: bool = False,
        rating: float | None = None,
    ) -> None:
        if isinstance(title_id, bool) or not isinstance(title_id, int) or title_id <= 0:
            raise ValueError("ID musi być dodatnią liczbą całkowitą.")
        if not isinstance(title, str) or not title.strip():
            raise ValueError("Tytuł nie może być pusty.")
        if isinstance(year, bool) or not isinstance(year, int) or year < 1888:
            raise ValueError("Rok musi być poprawną liczbą całkowitą.")
        if not isinstance(genre, str) or not genre.strip():
            raise ValueError("Gatunek nie może być pusty.")
        if not isinstance(platform, str) or not platform.strip():
            raise ValueError("Platforma nie może być pusta.")
        if not isinstance(is_watched, bool):
            raise TypeError("is_watched musi mieć wartość bool.")

        self._title_id = title_id
        self.title = title.strip()
        self.year = year
        self.genre = genre.strip()
        self.platform = platform.strip()
        self._is_watched = is_watched
        self._rating: float | None = None
        if rating is not None:
            self.rating = rating

    @property
    def title_id(self) -> int:
        """Identyfikator tytułu jest niemutowalny."""
        return self._title_id

    @property
    def is_watched(self) -> bool:
        return self._is_watched

    @is_watched.setter
    def is_watched(self, value: bool) -> None:
        if not isinstance(value, bool):
            raise TypeError("is_watched musi mieć wartość bool.")
        self._is_watched = value
        if not value:
            self._rating = None

    @property
    def rating(self) -> float | None:
        return self._rating

    @rating.setter
    def rating(self, value: float | None) -> None:
        if value is None:
            self._rating = None
            return
        if not self._is_watched:
            raise ValueError("Ocena może być przypisana wyłącznie obejrzanemu tytułowi.")
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError("Ocena musi być liczbą.")
        if not 1.0 <= float(value) <= 10.0:
            raise ValueError("Ocena musi mieścić się w przedziale 1.0–10.0.")
        self._rating = round(float(value), 1)

    @abstractmethod
    def calculate_playback_weight(self) -> float:
        """Zwraca łączny czas odtwarzania tytułu w minutach."""
        raise NotImplementedError

    def to_dict(self) -> dict[str, Any]:
        """Wspólne pola i dyskryminator typu; podklasa dodaje swoje pola."""
        return {
            "type": self.TYPE,
            "title_id": self.title_id,
            "title": self.title,
            "year": self.year,
            "genre": self.genre,
            "platform": self.platform,
            "is_watched": self.is_watched,
            "rating": self.rating,
        }

    def __eq__(self, other: object) -> bool:
        return isinstance(other, MediaTitle) and self.title_id == other.title_id

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(title_id={self.title_id}, title={self.title!r})"

    def __str__(self) -> str:
        rating = f"{self.rating:.1f}" if self.rating is not None else "-"
        status = "Tak" if self.is_watched else "Nie"
        return (
            f"| {self.title_id:<3} | {self.title:<25.25} | {self.genre:<12.12} "
            f"| {self.year:<4} | {self.platform:<12.12} | "
            f"{self.calculate_playback_weight():<8.1f} | {rating:<5} | {status:<5} |"
        )


class Movie(MediaTitle):
    """Film pełnometrażowy."""

    TYPE = "movie"

    def __init__(
        self,
        title_id: int,
        title: str,
        year: int,
        genre: str,
        platform: str,
        duration_min: int,
        director: str,
        theatrical_premiere: str,
        is_watched: bool = False,
        rating: float | None = None,
    ) -> None:
        super().__init__(title_id, title, year, genre, platform, is_watched, rating)
        if isinstance(duration_min, bool) or not isinstance(duration_min, int) or duration_min <= 0:
            raise ValueError("Czas trwania filmu musi być dodatnią liczbą minut.")
        if not director.strip():
            raise ValueError("Reżyser nie może być pusty.")
        if not theatrical_premiere.strip():
            raise ValueError("Data premiery kinowej nie może być pusta.")
        self.duration_min = duration_min
        self.director = director.strip()
        self.theatrical_premiere = theatrical_premiere.strip()

    def calculate_playback_weight(self) -> float:
        return float(self.duration_min)

    def to_dict(self) -> dict[str, Any]:
        data = super().to_dict()
        data.update({
            "duration_min": self.duration_min,
            "director": self.director,
            "theatrical_premiere": self.theatrical_premiere,
        })
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Movie:
        return cls(
            title_id=int(data["title_id"]),
            title=str(data["title"]),
            year=int(data["year"]),
            genre=str(data["genre"]),
            platform=str(data["platform"]),
            duration_min=int(data["duration_min"]),
            director=str(data["director"]),
            theatrical_premiere=str(data["theatrical_premiere"]),
            is_watched=bool(data.get("is_watched", False)),
            rating=data.get("rating"),
        )


class Series(MediaTitle):
    """Serial składający się z sezonów i odcinków."""

    TYPE = "series"

    def __init__(
        self,
        title_id: int,
        title: str,
        year: int,
        genre: str,
        platform: str,
        seasons: int,
        episodes_per_season: int,
        minutes_per_episode: int,
        is_watched: bool = False,
        rating: float | None = None,
    ) -> None:
        super().__init__(title_id, title, year, genre, platform, is_watched, rating)
        for field_name, value in (
            ("Liczba sezonów", seasons),
            ("Liczba odcinków na sezon", episodes_per_season),
            ("Minuty na odcinek", minutes_per_episode),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ValueError(f"{field_name} musi być dodatnią liczbą całkowitą.")
        self.seasons = seasons
        self.episodes_per_season = episodes_per_season
        self.minutes_per_episode = minutes_per_episode

    def calculate_playback_weight(self) -> float:
        return float(self.seasons * self.episodes_per_season * self.minutes_per_episode)

    def to_dict(self) -> dict[str, Any]:
        data = super().to_dict()
        data.update({
            "seasons": self.seasons,
            "episodes_per_season": self.episodes_per_season,
            "minutes_per_episode": self.minutes_per_episode,
        })
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Series:
        return cls(
            title_id=int(data["title_id"]),
            title=str(data["title"]),
            year=int(data["year"]),
            genre=str(data["genre"]),
            platform=str(data["platform"]),
            seasons=int(data["seasons"]),
            episodes_per_season=int(data["episodes_per_season"]),
            minutes_per_episode=int(data["minutes_per_episode"]),
            is_watched=bool(data.get("is_watched", False)),
            rating=data.get("rating"),
        )


# Fabryka wybiera klasę na podstawie znacznika "type" zapisanego w JSON.
ITEM_REGISTRY: dict[str, type[MediaTitle]] = {
    Movie.TYPE: Movie,
    Series.TYPE: Series,
}


def deserialize_media_title(data: dict[str, Any]) -> MediaTitle:
    item_type = data.get("type")
    target_class = ITEM_REGISTRY.get(item_type)
    if target_class is None:
        raise ValueError(f"Nieznany typ tytułu w pliku JSON: {item_type!r}")
    return target_class.from_dict(data)
