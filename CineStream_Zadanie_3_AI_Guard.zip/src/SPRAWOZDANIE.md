# CineStream – Zadanie 3

## Diagram hierarchii klas

```text
                 MediaTitle (ABC)
                 /              \
              Movie             Series

          MediaCatalogManager
          zarządza listą MediaTitle
```

## Kontrakt domenowy
- `MediaTitle` jest klasą abstrakcyjną.
- Każdy tytuł ma wspólne pola: ID, tytuł, rok, gatunek, platformę, status obejrzenia i ocenę.
- Każda podklasa implementuje `calculate_playback_weight()`.
- Ocena jest możliwa wyłącznie dla obejrzanego tytułu i mieści się w zakresie 1–10.

## Podklasy
- `Movie`: czas trwania w minutach, reżyser, data premiery kinowej.
- `Series`: liczba sezonów, liczba odcinków na sezon, minuty na odcinek.

## Polimorfizm
`MediaCatalogManager.total_playback_minutes()` i `platform_report()` wywołują
`calculate_playback_weight()` na każdym obiekcie. Nie rozpoznają, czy obiekt
jest filmem, czy serialem. Sposób obliczenia czasu określa konkretna podklasa.

## Polimorficzna persystencja JSON
Każdy obiekt zapisuje pole `type` (`movie` albo `series`). Funkcja
`deserialize_media_title()` korzysta z `ITEM_REGISTRY`, aby odtworzyć właściwą
klasę bez łańcucha `if/elif`.

## Menedżer
`MediaCatalogManager` odpowiada za dodawanie i usuwanie tytułów, filtrowanie,
sumowanie czasu, raport platform oraz zapis i odczyt JSON. Menu CLI korzysta
z menedżera, a nie manipuluje bezpośrednio wewnętrzną listą.

## Testy
Uruchomienie: `python test_manager.py`.
Testy sprawdzają klasę abstrakcyjną, polimorfizm, raport platform, filtr,
dyskryminator JSON oraz zapis i odczyt katalogu.
