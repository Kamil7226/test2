"""Warstwa trwałego zapisu katalogu."""
from pathlib import Path
from manager import MediaCatalogManager
from data import DEFAULT_TITLES

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_PATH = BASE_DIR / "data" / "catalog.json"
EXPORT_PATH = BASE_DIR / "exports" / "catalog.csv"


def load_manager() -> MediaCatalogManager:
    manager = MediaCatalogManager(DATA_PATH)
    if DATA_PATH.exists():
        manager.load_catalog()
    else:
        for title in DEFAULT_TITLES:
            manager.add_title(title)
        manager.save_catalog()
    return manager
