"""Główny punkt wejścia do aplikacji CineStream – Zadanie 3."""
from storage import load_manager, EXPORT_PATH
from validators import get_int_input
from services import (
    add_movie, add_series, display_movies,
    filter_movies_by_genre, show_platform_report,
)


def print_menu() -> None:
    print("\n" + "=" * 48)
    print("          CINESTREAM - MENADŻER VOD")
    print("=" * 48)
    print("1. Wyświetl katalog")
    print("2. Dodaj film")
    print("3. Dodaj serial")
    print("4. Filtruj po gatunku")
    print("5. Raport platform")
    print("6. Eksportuj katalog do CSV")
    print("7. Wyjście")
    print("-" * 48)


def main() -> None:
    manager = load_manager()
    running = True
    while running:
        print_menu()
        choice = get_int_input("Wybierz opcję [1-7]: ", 1, 7)
        try:
            if choice == 1:
                display_movies(manager)
            elif choice == 2:
                add_movie(manager)
            elif choice == 3:
                add_series(manager)
            elif choice == 4:
                filter_movies_by_genre(manager)
            elif choice == 5:
                show_platform_report(manager)
            elif choice == 6:
                count = manager.export_csv(EXPORT_PATH)
                print(f"Wyeksportowano {count} pozycji do {EXPORT_PATH}.")
            elif choice == 7:
                manager.save_catalog()
                print("Zamykanie CineStream. Do widzenia!")
                running = False
        except (ValueError, TypeError, KeyError) as error:
            print(f"[Błąd] {error}")


if __name__ == "__main__":
    main()
