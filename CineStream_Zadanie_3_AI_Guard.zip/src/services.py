"""Funkcje prezentacyjne używane przez CLI."""
from models import MediaTitle
from manager import MediaCatalogManager


def display_movies(manager: MediaCatalogManager) -> None:
    titles = manager.catalog
    if not titles:
        print("\n[Informacja] Katalog jest pusty.")
        return
    print("\n" + "-" * 115)
    print(
        f"| {'ID':<3} | {'Tytuł':<25} | {'Gatunek':<12} | {'Rok':<4} "
        f"| {'Platforma':<12} | {'Minuty':<8} | {'Ocena':<5} | {'Obejrz.':<5} |"
    )
    print("-" * 115)
    for title in titles:
        print(title)
    print("-" * 115)
    print(f"Liczba pozycji: {len(titles)}")
    print(f"Łączny czas: {manager.total_playback_hours():.2f} godz.\n")


def add_movie(manager: MediaCatalogManager) -> None:
    from validators import get_float_input, get_int_input, get_non_empty_string, get_yes_no

    print("\n--- DODAWANIE FILMU ---")
    new_id = max((title.title_id for title in manager.catalog), default=0) + 1
    name = get_non_empty_string("Tytuł: ")
    year = get_int_input("Rok premiery: ", 1888, 2100)
    genre = get_non_empty_string("Gatunek: ")
    platform = get_non_empty_string("Platforma: ")
    duration = get_int_input("Czas trwania w minutach: ", 1, 1000)
    director = get_non_empty_string("Reżyser: ")
    premiere = get_non_empty_string("Premiera kinowa (np. RRRR-MM-DD): ")
    watched = get_yes_no("Czy film został obejrzany? (tak/nie): ")
    rating = get_float_input("Ocena (1-10): ", 1.0, 10.0) if watched else None

    from models import Movie
    manager.add_title(Movie(
        new_id, name, year, genre, platform, duration,
        director, premiere, watched, rating
    ))
    manager.save_catalog()
    print(f"[Sukces] Dodano film: {name}.")


def add_series(manager: MediaCatalogManager) -> None:
    from validators import get_float_input, get_int_input, get_non_empty_string, get_yes_no
    from models import Series

    print("\n--- DODAWANIE SERIALU ---")
    new_id = max((title.title_id for title in manager.catalog), default=0) + 1
    name = get_non_empty_string("Tytuł: ")
    year = get_int_input("Rok premiery: ", 1888, 2100)
    genre = get_non_empty_string("Gatunek: ")
    platform = get_non_empty_string("Platforma: ")
    seasons = get_int_input("Liczba sezonów: ", 1, 100)
    episodes = get_int_input("Liczba odcinków na sezon: ", 1, 500)
    minutes = get_int_input("Minuty na odcinek: ", 1, 300)
    watched = get_yes_no("Czy serial został obejrzany? (tak/nie): ")
    rating = get_float_input("Ocena (1-10): ", 1.0, 10.0) if watched else None

    manager.add_title(Series(
        new_id, name, year, genre, platform, seasons,
        episodes, minutes, watched, rating
    ))
    manager.save_catalog()
    print(f"[Sukces] Dodano serial: {name}.")


def filter_movies_by_genre(manager: MediaCatalogManager) -> None:
    from validators import get_non_empty_string
    genre = get_non_empty_string("Podaj gatunek: ")
    results = manager.find_by_genre(genre)
    if not results:
        print("Nie znaleziono pozycji dla tego gatunku.")
    else:
        for title in results:
            print(title)


def show_platform_report(manager: MediaCatalogManager) -> None:
    report = manager.platform_report()
    if not report:
        print("Brak danych do raportu.")
        return
    print("\n--- RAPORT PLATFORM ---")
    for platform, minutes in report.items():
        print(f"{platform}: {minutes:.1f} min ({minutes / 60:.2f} godz.)")
