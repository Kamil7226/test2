"""Autotesty Zadania 3 – uruchom: python test_manager.py"""
import json
import tempfile
from pathlib import Path

from manager import MediaCatalogManager
from models import MediaTitle, Movie, Series, deserialize_media_title


def test_abstract_contract():
    try:
        MediaTitle(1, "Test", 2020, "Dramat", "Netflix")
        assert False, "Nie można tworzyć instancji klasy abstrakcyjnej."
    except TypeError:
        pass


def test_polymorphism_without_type_checks():
    movie = Movie(1, "Film", 2020, "Dramat", "Netflix", 120, "Reżyser", "2020-01-01")
    series = Series(2, "Serial", 2021, "Sci-Fi", "HBO", 2, 10, 40)
    manager = MediaCatalogManager(Path(tempfile.gettempdir()) / "cinestream_test_polymorphism.json")
    manager.add_title(movie)
    manager.add_title(series)
    assert movie.calculate_playback_weight() == 120.0
    assert series.calculate_playback_weight() == 800.0
    assert manager.total_playback_minutes() == 920.0
    assert manager.total_playback_hours() == round(920 / 60, 2)


def test_platform_report_and_filter():
    manager = MediaCatalogManager(Path(tempfile.gettempdir()) / "cinestream_test_report.json")
    manager.add_title(Movie(1, "Film A", 2020, "Dramat", "Netflix", 100, "A", "2020-01-01"))
    manager.add_title(Series(2, "Serial B", 2021, "Dramat", "Netflix", 1, 5, 30))
    manager.add_title(Movie(3, "Film C", 2022, "Komedia", "HBO", 90, "C", "2022-01-01"))
    assert manager.platform_report() == {"HBO": 90.0, "Netflix": 250.0}
    assert len(manager.find_by_genre("dramat")) == 2


def test_json_discriminator_round_trip():
    original = [
        Movie(1, "Incepcja", 2010, "Sci-Fi", "Netflix", 148, "Christopher Nolan", "2010-07-16", True, 8.8),
        Series(2, "Serial", 2022, "Dramat", "HBO", 2, 8, 45),
    ]
    payload = [item.to_dict() for item in original]
    assert payload[0]["type"] == "movie"
    assert payload[1]["type"] == "series"
    restored = [deserialize_media_title(row) for row in payload]
    assert [type(x).__name__ for x in restored] == ["Movie", "Series"]
    assert [x.to_dict() for x in restored] == payload


def test_manager_save_and_load():
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder) / "catalog.json"
        manager = MediaCatalogManager(path)
        manager.add_title(Movie(1, "Film", 2020, "Dramat", "Netflix", 100, "A", "2020-01-01"))
        manager.add_title(Series(2, "Serial", 2021, "Sci-Fi", "HBO", 1, 5, 30))
        manager.save_catalog()
        loaded = MediaCatalogManager(path)
        loaded.load_catalog()
        assert [type(x).__name__ for x in loaded.catalog] == ["Movie", "Series"]
        assert loaded.total_playback_minutes() == 250.0


def run_tests():
    tests = [
        test_abstract_contract,
        test_polymorphism_without_type_checks,
        test_platform_report_and_filter,
        test_json_discriminator_round_trip,
        test_manager_save_and_load,
    ]
    for test in tests:
        test()
        print(f"[OK] {test.__name__}")
    print("\nWszystkie testy Zadania 3 zakończone powodzeniem.")


if __name__ == "__main__":
    run_tests()
