# CineStream — Laboratorium 3.2

Wymaga Python 3.10+; bez zewnętrznych bibliotek.

```bash
python test_manager.py
python main.py
```

Przy pierwszym uruchomieniu katalog zostanie zapisany w `data/watchlist.json`.
Eksport CSV: `exports/watchlist.csv`. Kopie zapasowe: `data/backups/`.

**Uwaga:** stary format `watchlist.json` (bez pola `type`) nie jest automatycznie migrowany. Przed aktualizacją zachowaj kopię starych danych; nowe pliki zapisuj w oddzielnym katalogu projektu.
