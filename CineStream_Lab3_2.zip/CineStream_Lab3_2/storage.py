"""Bezpieczny zapis katalogu JSON i eksport CSV."""
import csv
import json
import os
import shutil
import tempfile
from datetime import datetime
from pathlib import Path
from data import default_catalog
from manager import MediaCatalogManager

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / 'data'
EXPORTS_DIR = BASE_DIR / 'exports'
CATALOG_FILE = DATA_DIR / 'watchlist.json'


def save_catalog(manager: MediaCatalogManager, path: Path = CATALOG_FILE) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=path.parent,
                                         suffix='.tmp', delete=False) as file:
            temporary = Path(file.name)
            json.dump(manager.to_dict(), file, ensure_ascii=False, indent=2, allow_nan=False)
            file.flush()
            os.fsync(file.fileno())
        # Backup dopiero po pomyślnym utworzeniu nowego pliku.
        if path.exists():
            backup_dir = path.parent / 'backups'
            backup_dir.mkdir(exist_ok=True)
            stamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
            shutil.copy2(path, backup_dir / f'{path.stem}_{stamp}.bak')
            for old in sorted(backup_dir.glob(f'{path.stem}_*.bak'))[:-3]:
                old.unlink()
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def load_catalog(path: Path = CATALOG_FILE) -> MediaCatalogManager:
    path = Path(path)
    if not path.exists():
        catalog = default_catalog()
        save_catalog(catalog, path)
        return catalog
    # Nie nadpisujemy uszkodzonego pliku domyślnymi danymi.
    try:
        with path.open(encoding='utf-8') as file:
            return MediaCatalogManager.from_dict(json.load(file))
    except (ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
        raise ValueError(f'Nie można odczytać katalogu {path}. Dane pozostawiono bez zmian: {exc}') from exc


def export_catalog_to_csv(manager: MediaCatalogManager, path: Path = EXPORTS_DIR / 'watchlist.csv') -> int:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ['type', 'title_id', 'title', 'year', 'rating', 'genre', 'is_watched',
              'platform', 'duration_min', 'director', 'theatrical_release',
              'seasons', 'episodes_per_season', 'minutes_per_episode']
    with path.open('w', newline='', encoding='utf-8-sig') as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        for item in manager.titles:
            writer.writerow(item.to_dict())
    return len(manager.titles)
