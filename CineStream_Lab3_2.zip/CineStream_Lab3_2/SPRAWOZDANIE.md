# CineStream — Zadanie 3, Laboratorium 3.2

## Hierarchia klas

```text
MediaTitle (ABC)
├── Movie
└── Series

MediaCatalogManager — zarządza kolekcją MediaTitle
```

## Dziedziczenie i polimorfizm

`MediaTitle` udostępnia wspólne pola: ID, tytuł, rok, ocena, gatunek, obejrzany i platforma.
Metody abstrakcyjne `calculate_playback_weight()`, `runtime_minutes()` i `media_kind()` są realizowane w podklasach.
`Movie` zawiera czas trwania, reżysera i informację o premierze kinowej.
`Series` zawiera liczbę sezonów, odcinków na sezon i długość odcinka.

**Przyjęte przez zespół wzory (nie zostały narzucone w instrukcji):**
- Film: `(czas_min / 60) * (1.1 jeśli premiera kinowa, w przeciwnym razie 1)`.
- Serial: `(sezony * odcinki_na_sezon * minuty_na_odcinek / 60) * (1 + 0.05 * (sezony - 1))`.

Wynik jest wagą odtwarzania w godzinach ekwiwalentnych; zwykły czas seansu liczony jest osobno.
Menedżer wywołuje te same metody niezależnie od rodzaju pozycji (bez `isinstance` w obliczeniach).

## Menedżer i persystencja

`MediaCatalogManager` odpowiada za dodawanie, usuwanie, filtrowanie, sortowanie, agregację czasu, sumę wag i raport platform.
CLI wywołuje metody menedżera, nie implementuje logiki katalogu.
Każda podklasa zapisuje w JSON pole `type` (`movie` albo `series`).
Fabryka `deserialize_media` korzysta z rejestru `MEDIA_REGISTRY`.
Zapis odbywa się przez plik tymczasowy i `os.replace`, z kopiami zapasowymi.
Uszkodzony JSON nie jest automatycznie nadpisywany.

## Testy i demonstracja

Uruchom `python test_manager.py`, a następnie `python main.py`.
Testy obejmują abstrakcyjność, polimorfizm, agregacje, serializację JSON i przypadki brzegowe.

## Git i praca zespołu

Do uzupełnienia przez autorów: imiona, daty, podział pracy, identyfikatory commitów oraz opis przeprowadzonej demonstracji i live-patchingu.
Przykładowe etapy commitów: modele → menedżer → zapis JSON → CLI → testy i dokumentacja.
