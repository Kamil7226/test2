"""Interfejs konsolowy CineStream."""
from storage import load_catalog, save_catalog, export_catalog_to_csv
from services import display_movies, add_media, show_statistics
from validators import get_int_input, get_non_empty_string


def main() -> None:
    try:
        manager = load_catalog()
    except (OSError, ValueError) as exc:
        print(f'[Błąd odczytu] {exc}')
        return
    while True:
        print('\n=== CINESTREAM ===')
        print('1. Katalog  2. Dodaj film/serial  3. Filtruj po gatunku')
        print('4. Eksport CSV  5. Sortuj według oceny  6. Statystyki  7. Usuń  8. Wyjście')
        choice = get_int_input('Wybierz [1-8]: ', 1, 8)
        try:
            if choice == 1:
                display_movies(manager)
            elif choice == 2:
                add_media(manager)
                save_catalog(manager)
            elif choice == 3:
                genre = get_non_empty_string('Gatunek: ')
                display_movies(manager, manager.filter_by_genre(genre))
            elif choice == 4:
                print(f'Wyeksportowano {export_catalog_to_csv(manager)} pozycji.')
            elif choice == 5:
                display_movies(manager, manager.sorted_by_rating())
            elif choice == 6:
                show_statistics(manager)
            elif choice == 7:
                title_id = get_int_input('ID do usunięcia: ', 1)
                if manager.remove_title(title_id):
                    save_catalog(manager)
                    print('Usunięto.')
                else:
                    print('Nie znaleziono ID.')
            elif choice == 8:
                save_catalog(manager)
                print('Do widzenia!')
                break
        except (ValueError, TypeError, OSError) as exc:
            print(f'[Błąd] {exc}')


if __name__ == '__main__':
    main()
