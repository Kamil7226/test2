"""Modele CineStream: dziedziczenie, polimorfizm i serializacja."""
from __future__ import annotations
from abc import ABC, abstractmethod
from math import isfinite
from typing import Any


def positive_int(value: int, name: str) -> int:
    if type(value) is not int or value <= 0:
        raise ValueError(f"{name} musi być dodatnią liczbą całkowitą.")
    return value


class MediaTitle(ABC):
    """Kontrakt wspólny dla filmu i serialu."""
    def __init__(self, title_id: int, title: str, year: int, rating: float | None,
                 genre: str, is_watched: bool, platform: str = 'CineStream') -> None:
        self._title_id = positive_int(title_id, 'ID')
        if not isinstance(title, str) or not title.strip():
            raise ValueError('Tytuł nie może być pusty.')
        if type(year) is not int or not 1888 <= year <= 2100:
            raise ValueError('Nieprawidłowy rok premiery.')
        if not isinstance(genre, str) or not genre.strip():
            raise ValueError('Gatunek nie może być pusty.')
        if not isinstance(platform, str) or not platform.strip():
            raise ValueError('Platforma nie może być pusta.')
        if type(is_watched) is not bool:
            raise TypeError('is_watched musi być wartością bool.')
        self.title = title.strip()
        self.year = year
        self.genre = genre.strip()
        self.platform = platform.strip()
        self._is_watched = is_watched
        self._rating = None
        self.rating = rating

    @property
    def title_id(self) -> int:
        return self._title_id

    @property
    def is_watched(self) -> bool:
        return self._is_watched

    @is_watched.setter
    def is_watched(self, value: bool) -> None:
        if type(value) is not bool:
            raise TypeError('is_watched musi być wartością bool.')
        self._is_watched = value
        if not value:
            self._rating = None

    @property
    def rating(self) -> float | None:
        return self._rating

    @rating.setter
    def rating(self, value: float | None) -> None:
        if value is None:
            self._rating = None
            return
        if not self.is_watched:
            raise ValueError('Nie można oceniać nieobejrzanego tytułu.')
        if type(value) not in (int, float) or not isfinite(value) or not 1 <= value <= 10:
            raise ValueError('Ocena musi być liczbą od 1 do 10.')
        self._rating = round(float(value), 1)

    @abstractmethod
    def calculate_playback_weight(self) -> float:
        """Zwraca wagę odtwarzania wyrażoną w godzinach ekwiwalentnych."""

    @abstractmethod
    def runtime_minutes(self) -> int:
        """Łączny czas odtwarzania w minutach."""

    @abstractmethod
    def media_kind(self) -> str:
        """Nazwa typu do prezentacji."""

    def to_dict(self) -> dict[str, Any]:
        return dict(title_id=self.title_id, title=self.title, year=self.year,
                    rating=self.rating, genre=self.genre, is_watched=self.is_watched,
                    platform=self.platform)

    def __lt__(self, other: MediaTitle) -> bool:
        return (-(self.rating or 0), self.title.casefold()) < (-(other.rating or 0), other.title.casefold())

    def __eq__(self, other: object) -> bool:
        return isinstance(other, MediaTitle) and self.title_id == other.title_id

    def __str__(self) -> str:
        rating = '-' if self.rating is None else f'{self.rating:.1f}'
        return (f'{self.title_id:>3} | {self.media_kind():<6} | {self.title:<24.24} | '
                f'{self.genre:<12.12} | {self.year} | {rating:>4} | '
                f'{self.runtime_minutes():>5} min | {self.platform}')


class Movie(MediaTitle):
    def __init__(self, title_id: int, title: str, year: int, rating: float | None,
                 genre: str, is_watched: bool, duration_min: int, director: str,
                 theatrical_release: bool, platform: str = 'CineStream') -> None:
        super().__init__(title_id, title, year, rating, genre, is_watched, platform)
        self.duration_min = positive_int(duration_min, 'Czas filmu')
        if not isinstance(director, str) or not director.strip():
            raise ValueError('Reżyser nie może być pusty.')
        if type(theatrical_release) is not bool:
            raise TypeError('Premiera kinowa musi być bool.')
        self.director = director.strip()
        self.theatrical_release = theatrical_release

    def runtime_minutes(self) -> int:
        return self.duration_min

    def calculate_playback_weight(self) -> float:
        # Własna reguła domenowa: czas filmu w godzinach, premiera kinowa +10%.
        return round(self.duration_min / 60 * (1.1 if self.theatrical_release else 1), 2)

    def media_kind(self) -> str:
        return 'Film'

    def to_dict(self) -> dict[str, Any]:
        return {**super().to_dict(), 'type': 'movie', 'duration_min': self.duration_min,
                'director': self.director, 'theatrical_release': self.theatrical_release}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Movie:
        return cls(data['title_id'], data['title'], data['year'], data['rating'],
                   data['genre'], data['is_watched'], data['duration_min'],
                   data['director'], data['theatrical_release'], data.get('platform', 'CineStream'))


class Series(MediaTitle):
    def __init__(self, title_id: int, title: str, year: int, rating: float | None,
                 genre: str, is_watched: bool, seasons: int, episodes_per_season: int,
                 minutes_per_episode: int, platform: str = 'CineStream') -> None:
        super().__init__(title_id, title, year, rating, genre, is_watched, platform)
        self.seasons = positive_int(seasons, 'Liczba sezonów')
        self.episodes_per_season = positive_int(episodes_per_season, 'Liczba odcinków')
        self.minutes_per_episode = positive_int(minutes_per_episode, 'Długość odcinka')

    def runtime_minutes(self) -> int:
        return self.seasons * self.episodes_per_season * self.minutes_per_episode

    def calculate_playback_weight(self) -> float:
        # Własna reguła domenowa: czas serialu w godzinach, +5% na każdy sezon po pierwszym.
        return round(self.runtime_minutes() / 60 * (1 + 0.05 * (self.seasons - 1)), 2)

    def media_kind(self) -> str:
        return 'Serial'

    def to_dict(self) -> dict[str, Any]:
        return {**super().to_dict(), 'type': 'series', 'seasons': self.seasons,
                'episodes_per_season': self.episodes_per_season,
                'minutes_per_episode': self.minutes_per_episode}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Series:
        return cls(data['title_id'], data['title'], data['year'], data['rating'],
                   data['genre'], data['is_watched'], data['seasons'],
                   data['episodes_per_season'], data['minutes_per_episode'],
                   data.get('platform', 'CineStream'))


MEDIA_REGISTRY: dict[str, type[MediaTitle]] = {'movie': Movie, 'series': Series}


def deserialize_media(payload: dict[str, Any]) -> MediaTitle:
    if not isinstance(payload, dict):
        raise ValueError('Pozycja katalogu musi być słownikiem.')
    media_type = payload.get('type')
    cls = MEDIA_REGISTRY.get(media_type)
    if cls is None:
        raise ValueError(f'Nieznany typ mediów: {media_type!r}')
    return cls.from_dict(payload)
