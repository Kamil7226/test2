"""Migracja starego katalogu CineStream z JSON do relacyjnej bazy SQLite.

Obsługiwane formaty wejściowe:
1. Obiekt watchlist: {"watchlist_id": 1, "name": "...", "titles": [...]}
2. Lista rekordów: [{...}, {...}]
3. Rekordy z Zadania 3 posiadające pole "type" (movie/series).

Migracja uruchamia się tylko wtedy, gdy baza nie zawiera jeszcze list.
Po poprawnym zapisie i weryfikacji plik JSON jest archiwizowany jako .json.bak.
"""
import json
import shutil
from pathlib import Path
from typing import Any

from models import Movie, MediaTitle, deserialize_media_title
from repository import MediaCatalogRepository


def _legacy_title_to_model(row: dict[str, Any]) -> MediaTitle:
    """Konwertuje pojedynczy rekord starego JSON na obiekt domenowy."""
    if row.get("type") in ("movie", "series"):
        return deserialize_media_title(row)

    year = int(row["year"])
    watched = bool(row.get("is_watched", False))
    rating = row.get("rating")

    # W starym formacie z Zadania 2 nie było typu, platformy ani reżysera.
    # Takie rekordy traktujemy jako filmy i uzupełniamy brakujące dane
    # neutralnymi wartościami, zachowując dostępne informacje.
    if not watched:
        rating = None

    return Movie(
        title_id=int(row["title_id"]),
        title=str(row["title"]),
        year=year,
        genre=str(row.get("genre") or "Nieznany"),
        platform=str(row.get("platform") or "Nieznana"),
        duration_min=int(row["duration_min"]),
        director=str(row.get("director") or "Nieznany"),
        theatrical_premiere=str(
            row.get("theatrical_premiere") or f"{year}-01-01"
        ),
        is_watched=watched,
        rating=rating,
    )


def migrate_json_to_sqlite(
    json_path: str | Path,
    repository: MediaCatalogRepository,
) -> bool:
    """Przenosi dane JSON do SQLite.

    Zwraca:
        True  – migracja została wykonana.
        False – baza nie jest pusta albo plik JSON nie istnieje.

    Cały agregat jest zapisywany w transakcji repozytorium. Plik źródłowy
    jest archiwizowany dopiero po potwierdzeniu liczby przeniesionych rekordów.
    """
    source = Path(json_path)

    # Ochrona przed ponownym importem i duplikowaniem danych.
    if repository.count_watchlists() != 0 or not source.exists():
        return False

    with source.open("r", encoding="utf-8") as file:
        raw: Any = json.load(file)

    if isinstance(raw, dict):
        name = str(raw.get("name") or "Katalog CineStream")
        created_at = str(raw.get("created_at") or "2026-01-01T00:00:00")
        watchlist_id = int(raw.get("watchlist_id") or 1)
        raw_titles = raw.get("titles", [])
    elif isinstance(raw, list):
        name = "Katalog CineStream"
        created_at = "2026-01-01T00:00:00"
        watchlist_id = 1
        raw_titles = raw
    else:
        raise ValueError("Nieobsługiwany format pliku JSON.")

    if not isinstance(raw_titles, list):
        raise ValueError("Pole 'titles' w pliku JSON musi być listą.")

    titles = [_legacy_title_to_model(row) for row in raw_titles]
    repository.save_watchlist(name, titles, created_at, watchlist_id)

    # Weryfikacja po COMMIT – nie archiwizujemy źródła, jeśli liczba
    # rekordów w SQLite nie zgadza się z liczbą rekordów wejściowych.
    imported = repository.count_media_items()
    if imported != len(titles):
        raise RuntimeError(
            f"Niepełna migracja: JSON zawiera {len(titles)} pozycji, "
            f"a SQLite zawiera {imported}."
        )

    backup = source.with_suffix(source.suffix + ".bak")
    if backup.exists():
        backup = source.with_name(source.name + ".migrated.bak")
    shutil.move(str(source), str(backup))
    return True
