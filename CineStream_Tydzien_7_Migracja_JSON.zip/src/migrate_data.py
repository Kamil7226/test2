"""Ręczne uruchomienie migracji starego JSON do SQLite.

Użycie z katalogu src:
    python migrate_data.py
"""
from storage import (
    DB_PATH,
    LEGACY_JSON_PATH,
)
from database import initialize_database
from repository import MediaCatalogRepository
from migration import migrate_json_to_sqlite

def main() -> None:
    initialize_database(DB_PATH)
    repository = MediaCatalogRepository(DB_PATH)

    before = repository.count_media_items()
    migrated = migrate_json_to_sqlite(LEGACY_JSON_PATH, repository)
    after = repository.count_media_items()

    if migrated:
        print("[OK] Migracja JSON -> SQLite zakończona.")
        print(f"Przeniesiono pozycji: {after - before}")
        print(f"Baza danych: {DB_PATH}")
        print(f"Archiwum JSON: {LEGACY_JSON_PATH}.bak")
    elif not LEGACY_JSON_PATH.exists():
        print("[INFO] Nie znaleziono starego pliku JSON. Nie ma czego migrować.")
    else:
        print("[INFO] Baza zawiera już listę. Migracja została pominięta, aby uniknąć duplikatów.")

if __name__ == "__main__":
    main()
