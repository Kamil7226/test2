"""Punkt kontrolny Tygodnia 7. Uruchom: python test_database.py"""
import json
import sqlite3
import tempfile
from pathlib import Path

from database import get_connection, initialize_database
from migration import migrate_json_to_sqlite
from models import Movie, Series
from repository import MediaCatalogRepository

def test_schema_and_foreign_key_cascade():
    with tempfile.TemporaryDirectory() as folder:
        db = Path(folder) / "test.db"
        initialize_database(db)
        with get_connection(db) as conn:
            tables = {row["name"] for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )}
            assert {"watchlists", "media_items"} <= tables
            fk = conn.execute("PRAGMA foreign_key_list(media_items)").fetchall()
            assert len(fk) == 1
            assert fk[0]["table"] == "watchlists"
            assert fk[0]["on_delete"] == "CASCADE"

def test_foreign_key_rejects_missing_parent():
    with tempfile.TemporaryDirectory() as folder:
        db = Path(folder) / "test.db"
        initialize_database(db)
        with get_connection(db) as conn:
            try:
                conn.execute(
                    """INSERT INTO media_items
                       (watchlist_id, title, year, is_watched, duration_min, genre, platform)
                       VALUES (999, 'Osierocony rekord', 2024, 0, 90, 'Dramat', 'Netflix')"""
                )
                assert False, "Oczekiwano sqlite3.IntegrityError dla nieistniejącego rodzica."
            except sqlite3.IntegrityError:
                pass

def test_repository_save_and_read_aggregate():
    with tempfile.TemporaryDirectory() as folder:
        db = Path(folder) / "test.db"
        repo = MediaCatalogRepository(db)
        titles = [
            Movie(1, "Incepcja", 2010, "Sci-Fi", "Netflix", 148,
                  "Christopher Nolan", "2010-07-16", True, 8.8),
            Series(2, "Serial", 2022, "Dramat", "HBO", 2, 8, 45),
        ]
        watchlist_id = repo.save_watchlist("Testowa lista", titles)
        aggregate = repo.get_watchlist(watchlist_id)
        assert aggregate is not None
        assert aggregate["name"] == "Testowa lista"
        assert [type(x).__name__ for x in aggregate["titles"]] == ["Movie", "Series"]
        assert aggregate["titles"][0].title == "Incepcja"
        assert aggregate["titles"][1].calculate_playback_weight() == 720.0

def test_cascade_delete_removes_children():
    with tempfile.TemporaryDirectory() as folder:
        db = Path(folder) / "test.db"
        repo = MediaCatalogRepository(db)
        watchlist_id = repo.save_watchlist(
            "Do usunięcia",
            [Movie(1, "Film", 2020, "Dramat", "Netflix", 100, "Reżyser", "2020-01-01")]
        )
        assert repo.count_media_items() == 1
        assert repo.delete_watchlist(watchlist_id) is True
        assert repo.count_media_items() == 0

def test_json_migration_is_successful_and_idempotent():
    with tempfile.TemporaryDirectory() as folder:
        base = Path(folder)
        json_path = base / "watchlist.json"
        json_path.write_text(json.dumps({
            "watchlist_id": 1,
            "name": "Katalog z JSON",
            "created_at": "2026-01-01T12:00:00",
            "titles": [
                {"title_id": 1, "title": "Film z JSON", "year": 2020,
                 "rating": 9.2, "genre": "Sci-Fi", "is_watched": True,
                 "duration_min": 120}
            ]
        }, ensure_ascii=False), encoding="utf-8")
        repo = MediaCatalogRepository(base / "test.db")
        assert migrate_json_to_sqlite(json_path, repo) is True
        assert repo.count_watchlists() == 1
        assert repo.count_media_items() == 1
        assert migrate_json_to_sqlite(json_path, repo) is False
        aggregate = repo.get_watchlist(1)
        assert aggregate is not None
        assert aggregate["titles"][0].title == "Film z JSON"
        assert aggregate["titles"][0].rating == 9.2
        assert (base / "watchlist.json.bak").exists()

def test_memory_database_foreign_keys():
    conn = get_connection(":memory:")
    try:
        conn.execute("""CREATE TABLE parent (id INTEGER PRIMARY KEY)""")
        conn.execute("""CREATE TABLE child (
            id INTEGER PRIMARY KEY,
            parent_id INTEGER NOT NULL,
            FOREIGN KEY(parent_id) REFERENCES parent(id) ON DELETE CASCADE
        )""")
        try:
            conn.execute("INSERT INTO child (id, parent_id) VALUES (1, 77)")
            assert False, "Klucz obcy powinien blokować rekord."
        except sqlite3.IntegrityError:
            pass
    finally:
        conn.close()


def test_migration_of_real_legacy_watchlist_format():
    with tempfile.TemporaryDirectory() as folder:
        base = Path(folder)
        source = base / "watchlist.json"
        source.write_text(json.dumps({
            "watchlist_id": 1,
            "name": "Stary katalog CineStream",
            "titles": [
                {"title_id": 1, "title": "Incepcja", "year": 2010,
                 "rating": 8.8, "genre": "Sci-Fi", "is_watched": True,
                 "duration_min": 148},
                {"title_id": 2, "title": "Shrek", "year": 2001,
                 "rating": None, "genre": "Animacja", "is_watched": False,
                 "duration_min": 90}
            ]
        }, ensure_ascii=False), encoding="utf-8")

        repo = MediaCatalogRepository(base / "cinestream.db")
        assert migrate_json_to_sqlite(source, repo) is True
        aggregate = repo.get_watchlist(1)
        assert aggregate is not None
        assert aggregate["name"] == "Stary katalog CineStream"
        assert len(aggregate["titles"]) == 2
        assert aggregate["titles"][0].title == "Incepcja"
        assert aggregate["titles"][0].rating == 8.8
        assert aggregate["titles"][1].title == "Shrek"
        assert aggregate["titles"][1].rating is None
        assert (base / "watchlist.json.bak").exists()
        assert not source.exists()

def run_tests():
    tests = [
        test_schema_and_foreign_key_cascade,
        test_foreign_key_rejects_missing_parent,
        test_repository_save_and_read_aggregate,
        test_cascade_delete_removes_children,
        test_json_migration_is_successful_and_idempotent,
        test_memory_database_foreign_keys,
    ]
    for test in tests:
        test()
        print(f"[OK] {test.__name__}")
    print("\\nWszystkie testy Tygodnia 7 zakończone powodzeniem.")

if __name__ == "__main__":
    run_tests()
