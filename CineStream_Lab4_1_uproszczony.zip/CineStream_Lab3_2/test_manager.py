"""Autotesty Laboratorium 3.2: python test_manager.py"""
import json
import tempfile
from pathlib import Path
from models import MediaTitle, Movie, Series, deserialize_media
from manager import MediaCatalogManager
from storage import save_catalog, load_catalog, export_catalog_to_csv


def test_abstract():
    try:
        MediaTitle(1, 'Test', 2024, None, 'Dramat', False)
        assert False, 'Klasa abstrakcyjna nie powinna dać się utworzyć'
    except TypeError:
        pass


def test_polymorphism():
    movie = Movie(1, 'Film', 2024, 8, 'Dramat', True, 120, 'Reżyser', True)
    series = Series(2, 'Serial', 2024, None, 'Dramat', False, 2, 5, 30)
    assert movie.calculate_playback_weight() == 2.2
    assert series.calculate_playback_weight() == 5.25
    manager = MediaCatalogManager(titles=[movie, series])
    assert manager.total_runtime_minutes() == 420
    assert manager.total_playback_weight() == 7.45
    assert manager.platform_report() == {'CineStream': 2}
    assert len(manager.filter_by_genre('dramat')) == 2


def test_json_roundtrip():
    manager = MediaCatalogManager(titles=[Movie(1, 'Film', 2020, None, 'Sci-Fi', False, 90, 'X', False),
                                          Series(2, 'Serial', 2020, None, 'Sci-Fi', False, 1, 2, 40)])
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / 'catalog.json'
        save_catalog(manager, path)
        restored = load_catalog(path)
        assert restored.to_dict() == manager.to_dict()
        assert type(restored.titles[0]) is Movie
        assert type(restored.titles[1]) is Series
        assert export_catalog_to_csv(restored, Path(directory) / 'out.csv') == 2


def test_edge_cases():
    manager = MediaCatalogManager()
    assert manager.total_runtime_minutes() == 0
    assert manager.platform_report() == {}
    item = Movie(1, 'Film', 2020, None, 'Dramat', False, 90, 'X', False)
    manager.add_title(item)
    try:
        manager.add_title(item)
        assert False
    except ValueError:
        pass
    try:
        deserialize_media({'type': 'unknown'})
        assert False
    except ValueError:
        pass
    try:
        Movie(2, 'Film', 2020, 8, 'Dramat', False, 90, 'X', False)
        assert False
    except ValueError:
        pass
    try:
        Movie(2, 'Film', 2020, None, 'Dramat', 'False', 90, 'X', False)
        assert False
    except TypeError:
        pass
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / 'bad.json'
        path.write_text('{invalid', encoding='utf-8')
        try:
            load_catalog(path)
            assert False
        except ValueError:
            pass
        assert path.read_text(encoding='utf-8') == '{invalid'


def run_tests():
    for test in [test_abstract, test_polymorphism, test_json_roundtrip, test_edge_cases]:
        test()
        print('[OK]', test.__name__)
    print('Wszystkie testy zaliczone.')


if __name__ == '__main__':
    run_tests()
