"""Warstwa biznesowa katalogu, bez zależności od CLI."""
from collections import Counter
from models import MediaTitle, deserialize_media


class MediaCatalogManager:
    def __init__(self, name: str = 'Katalog CineStream', titles=None):
        self.name = name
        self._titles: list[MediaTitle] = []
        for title in titles or []:
            self.add_title(title)

    @property
    def titles(self) -> list[MediaTitle]:
        return list(self._titles)

    def next_id(self) -> int:
        return max((title.title_id for title in self._titles), default=0) + 1

    def add_title(self, title: MediaTitle) -> None:
        if not isinstance(title, MediaTitle):
            raise TypeError('Wymagany obiekt MediaTitle.')
        if any(item.title_id == title.title_id for item in self._titles):
            raise ValueError('ID już istnieje.')
        self._titles.append(title)

    def remove_title(self, title_id: int) -> bool:
        for item in self._titles:
            if item.title_id == title_id:
                self._titles.remove(item)
                return True
        return False

    def filter_by_genre(self, genre: str) -> list[MediaTitle]:
        return [item for item in self._titles if genre.casefold() in item.genre.casefold()]

    def sorted_by_rating(self) -> list[MediaTitle]:
        return sorted(self._titles)

    def total_runtime_minutes(self) -> int:
        return sum(item.runtime_minutes() for item in self._titles)

    def total_runtime_hours(self) -> float:
        return round(self.total_runtime_minutes() / 60, 2)

    def total_playback_weight(self) -> float:
        return round(sum(item.calculate_playback_weight() for item in self._titles), 2)

    def platform_report(self) -> dict[str, int]:
        return dict(Counter(item.platform for item in self._titles))

    def to_dict(self) -> dict:
        return {'name': self.name, 'titles': [item.to_dict() for item in self._titles]}

    @classmethod
    def from_dict(cls, payload: dict) -> 'MediaCatalogManager':
        return cls(payload['name'], [deserialize_media(row) for row in payload['titles']])
