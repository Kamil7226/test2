"""Domyślny katalog filmów i seriali."""
from models import Movie, Series
from manager import MediaCatalogManager


def default_catalog() -> MediaCatalogManager:
    return MediaCatalogManager('Katalog CineStream', [
        Movie(1, 'Incepcja', 2010, 8.8, 'Sci-Fi', True, 148, 'Christopher Nolan', True),
        Movie(2, 'Skazani na Shawshank', 1994, 9.3, 'Dramat', True, 142, 'Frank Darabont', True),
        Movie(3, 'Interstellar', 2014, 8.7, 'Sci-Fi', True, 169, 'Christopher Nolan', True),
        Movie(4, 'Shrek', 2001, None, 'Animacja', False, 90, 'Andrew Adamson, Vicky Jenson', True),
        Movie(5, 'Shrek 2', 2004, None, 'Animacja', False, 93, 'Andrew Adamson, Kelly Asbury, Conrad Vernon', True),
        Movie(6, 'Odyseja', 2026, None, 'Dramat', False, 150, 'Nieznany', False),
        Series(7, 'Przykładowy serial', 2024, None, 'Dramat', False, 2, 8, 45, 'CineStream'),
    ])
