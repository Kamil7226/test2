"""Jednorazowa, bezstratna migracja JSON -> SQLite."""
from pathlib import Path
from database import DB_FILE, get_connection, init_database, WatchlistRepository
from storage import CATALOG_FILE, load_catalog


def migrate_json_to_sqlite(json_path=CATALOG_FILE, db_path=DB_FILE):
    json_path = Path(json_path)
    if not json_path.is_file():
        return False
    conn = get_connection(db_path)
    try:
        init_database(conn)
        repository = WatchlistRepository(conn)
        if repository.count_watchlists() != 0:
            return False
        # Odczyt przez istniejącą fabrykę from_dict(), bez generowania danych domyślnych.
        manager = load_catalog(json_path)
        repository.save_watchlist(manager)
        # Archiwizacja dopiero po zatwierdzonym zapisie całego agregatu.
        backup_path = json_path.with_name(json_path.name + '.bak')
        if not backup_path.exists():
            json_path.rename(backup_path)
        return True
    finally:
        conn.close()


if __name__ == '__main__':
    print('Migracja zakończona.' if migrate_json_to_sqlite() else 'Migracja pominięta (brak JSON lub baza niepusta).')
