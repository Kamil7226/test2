"""Interfejs konsolowy CineStream."""
from storage import load_catalog_sqlite, save_catalog_sqlite, export_catalog_to_csv
from services import display_movies, add_media, show_statistics
from validators import get_int_input, get_non_empty_string
from models import MovieHit, SeriesHit


def main() -> None:
    try:
        manager = load_catalog_sqlite()
    except (OSError, ValueError) as exc:
        print(f'[Błąd odczytu] {exc}')
        return
    while True:
        print("\n" + "=" * 48)
        print("          CINESTREAM - MENADŻER VOD")
        print("=" * 48)
        print("1. Wyświetl katalog filmów")
        print("2. Dodaj nowy film")
        print("3. Filtruj filmy po gatunku")
        print("4. Eksportuj katalog do CSV")
        print("5. Sortuj filmy według oceny")
        print("6. Statystyki")
        print("7. Usuń")
        print("8. Największy hit")
        print("9. Wyjście")
        print("-" * 48)
        choice = get_int_input('Wybierz [1-9]: ', 1, 9)
        try:
            if choice == 1:
                display_movies(manager)
            elif choice == 2:
                add_media(manager)
                save_catalog_sqlite(manager)
            elif choice == 3:
                genre = get_non_empty_string('Gatunek: ')
                display_movies(manager, manager.filter_by_genre(genre))
            elif choice == 4:
                print(f'Wyeksportowano {export_catalog_to_csv(manager)} pozycji.')
            elif choice == 5:
                display_movies(manager, manager.sorted_by_rating())
            elif choice == 6:
                show_statistics(manager)
            elif choice == 7:
                title_id = get_int_input('ID do usunięcia: ', 1)
                if manager.remove_title(title_id):
                    save_catalog_sqlite(manager)
                    print('Usunięto.')
                else:
                    print('Nie znaleziono ID.')
            elif choice == 8:
                MovieHit().show_hit(manager.titles)
                SeriesHit().show_hit(manager.titles)
            elif choice == 9:
                save_catalog_sqlite(manager)
                print('Do widzenia!')
                break
        except (ValueError, TypeError, OSError) as exc:
            print(f'[Błąd] {exc}')


if __name__ == '__main__':
    main()
