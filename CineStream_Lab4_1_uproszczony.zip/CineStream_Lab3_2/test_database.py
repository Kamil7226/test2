"""Punkt kontrolny Lab 4.1: python test_database.py"""
import json
import sqlite3
import tempfile
from pathlib import Path
from database import get_connection, init_database, WatchlistRepository
from manager import MediaCatalogManager
from models import Movie, Series
from migrate import migrate_json_to_sqlite


def sample():
    return MediaCatalogManager('Test', [
        Movie(1, 'Film', 2024, 8.5, 'Dramat', True, 120, 'Reżyser', True),
        Series(2, 'Serial', 2023, None, 'Komedia', False, 2, 4, 45)])


def run_tests():
    with tempfile.TemporaryDirectory() as tmp:
        db = Path(tmp) / 'test.db'
        conn = get_connection(db)
        try:
            init_database(conn)
            assert conn.execute('PRAGMA foreign_keys').fetchone()[0] == 1
            tables = {r['name'] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            assert {'watchlists', 'media_items'} <= tables
            fk = conn.execute('PRAGMA foreign_key_list(media_items)').fetchall()
            assert any(r['table'] == 'watchlists' and r['on_delete'] == 'CASCADE' for r in fk)
            print('[OK] 1. Schemat dwóch tabel i ON DELETE CASCADE')

            try:
                with conn:
                    conn.execute('''INSERT INTO media_items
                        (watchlist_id, title, is_watched, duration_min, title_id, media_type,
                         genre, platform, details_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                        (99999, 'Sierota', 0, 60, 1, 'movie', 'Dramat', 'Test', '{}'))
                raise AssertionError('Nie wykryto nieistniejącego rodzica')
            except sqlite3.IntegrityError:
                pass
            print('[OK] 2. IntegrityError przy nieistniejącym kluczu obcym')

            repo = WatchlistRepository(conn)
            original = sample()
            wid = repo.save_watchlist(original)
            assert repo.count_items(wid) == 2
            assert repo.load_watchlist(wid).to_dict() == original.to_dict()
            print('[OK] 3. Transakcyjny zapis i odczyt agregatu')

            try:
                repo.save_watchlist(MediaCatalogManager('Błędny', [
                    Movie(3, 'Poprawny', 2024, None, 'Dramat', False, 90, 'X', False),
                    Movie(4, 'Drugi', 2024, None, 'Dramat', False, 90, 'X', False)]))
                # Test CHECK SQL bez polegania na walidatorze modelu.
                with conn:
                    conn.execute('UPDATE media_items SET rating = 11 WHERE watchlist_id = ?', (wid,))
                raise AssertionError('CHECK nie działa')
            except sqlite3.IntegrityError:
                pass
            assert repo.count_items(wid) == 2
            print('[OK] 4. Ograniczenia CHECK')

            assert repo.delete_watchlist(wid)
            assert repo.count_items(wid) == 0
            print('[OK] 5. Usuwanie kaskadowe')
        finally:
            conn.close()

        migration_db = Path(tmp) / 'migration.db'
        json_path = Path(tmp) / 'watchlist.json'
        original = sample()
        json_path.write_text(json.dumps(original.to_dict(), ensure_ascii=False), encoding='utf-8')
        assert migrate_json_to_sqlite(json_path, migration_db)
        assert not json_path.exists()
        assert Path(str(json_path) + '.bak').exists()
        assert not migrate_json_to_sqlite(json_path, migration_db)
        conn = get_connection(migration_db)
        try:
            repo = WatchlistRepository(conn)
            assert repo.count_watchlists() == 1
            assert repo.load_watchlist(repo.first_watchlist_id()).to_dict() == original.to_dict()
        finally:
            conn.close()
        print('[OK] 6. Migracja JSON, archiwizacja, brak duplikatów')
    print('Wszystkie testy bazy danych zaliczone.')


if __name__ == '__main__':
    run_tests()
