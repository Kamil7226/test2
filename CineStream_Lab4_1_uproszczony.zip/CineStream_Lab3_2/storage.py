"""Odczyt JSON (do migracji), eksport CSV i zapis SQLite."""
import csv
import json
from pathlib import Path

from data import default_catalog
from manager import MediaCatalogManager

BASE_DIR = Path(__file__).resolve().parent
CATALOG_FILE = BASE_DIR / 'data' / 'watchlist.json'
EXPORTS_DIR = BASE_DIR / 'exports'


def save_catalog(manager, path=CATALOG_FILE):
    """Zapis JSON zachowany dla zgodności z laboratorium 3."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8') as file:
        json.dump(manager.to_dict(), file, ensure_ascii=False, indent=2)


def load_catalog(path=CATALOG_FILE):
    path = Path(path)
    if not path.exists():
        catalog = default_catalog()
        save_catalog(catalog, path)
        return catalog
    with path.open(encoding='utf-8') as file:
        return MediaCatalogManager.from_dict(json.load(file))


def export_catalog_to_csv(manager, path=EXPORTS_DIR / 'watchlist.csv'):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ['type', 'title_id', 'title', 'year', 'rating', 'genre', 'is_watched',
              'platform', 'duration_min', 'director', 'theatrical_release',
              'seasons', 'episodes_per_season', 'minutes_per_episode']
    with path.open('w', newline='', encoding='utf-8-sig') as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        for item in manager.titles:
            writer.writerow(item.to_dict())
    return len(manager.titles)


def load_catalog_sqlite(db_path=None):
    from database import DB_FILE, get_connection, init_database, WatchlistRepository
    from migrate import migrate_json_to_sqlite
    db_path = db_path or DB_FILE
    migrate_json_to_sqlite(CATALOG_FILE, db_path)
    conn = get_connection(db_path)
    try:
        init_database(conn)
        repo = WatchlistRepository(conn)
        watchlist_id = repo.first_watchlist_id()
        if watchlist_id is None:
            manager = default_catalog()
            repo.save_watchlist(manager)
            return manager
        return repo.load_watchlist(watchlist_id)
    finally:
        conn.close()


def save_catalog_sqlite(manager, db_path=None):
    from database import DB_FILE, get_connection, init_database, WatchlistRepository
    conn = get_connection(db_path or DB_FILE)
    try:
        init_database(conn)
        repo = WatchlistRepository(conn)
        watchlist_id = repo.first_watchlist_id()
        if watchlist_id is None:
            repo.save_watchlist(manager)
        else:
            repo.replace_watchlist(watchlist_id, manager)
    finally:
        conn.close()
