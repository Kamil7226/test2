"""Obsługa wejścia i wyjścia CLI, bez reguł biznesowych."""
from models import Movie, Series
from manager import MediaCatalogManager
from validators import get_float_input, get_int_input, get_non_empty_string, get_yes_no


def display_movies(manager: MediaCatalogManager, titles=None) -> None:
    titles = manager.titles if titles is None else titles
    if not titles:
        print('Brak pozycji.')
        return
    for title in titles:
        print(title)
    print(f'Łączny czas całego katalogu: {manager.total_runtime_hours():.2f} godz.')


def add_media(manager: MediaCatalogManager) -> None:
    kind = get_int_input('1 - film, 2 - serial: ', 1, 2)
    title = get_non_empty_string('Tytuł: ')
    genre = get_non_empty_string('Gatunek: ')
    year = get_int_input('Rok: ', 1888, 2100)
    platform = get_non_empty_string('Platforma: ')
    watched = get_yes_no('Obejrzany? (tak/nie): ')
    rating = get_float_input('Ocena (1-10): ', 1, 10) if watched else None
    common = (manager.next_id(), title, year, rating, genre, watched)
    if kind == 1:
        duration = get_int_input('Czas trwania [min]: ', 1)
        director = get_non_empty_string('Reżyser: ')
        theatrical = get_yes_no('Premiera kinowa? (tak/nie): ')
        item = Movie(*common, duration, director, theatrical, platform)
    else:
        seasons = get_int_input('Sezony: ', 1)
        episodes = get_int_input('Odcinki na sezon: ', 1)
        minutes = get_int_input('Minuty na odcinek: ', 1)
        item = Series(*common, seasons, episodes, minutes, platform)
    manager.add_title(item)
    print('Dodano:', item.title)


def show_statistics(manager: MediaCatalogManager) -> None:
    print(f'Łączny czas: {manager.total_runtime_hours():.2f} godz.')
    print(f'Wskaźnik zaangażowania czasowego: {manager.total_playback_weight():.2f}')
    print('Raport platform:')
    for platform, count in sorted(manager.platform_report().items()):
        print(f'  {platform}: {count}')
