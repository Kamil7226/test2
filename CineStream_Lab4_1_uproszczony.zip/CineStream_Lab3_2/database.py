"""SQLite CineStream: schemat 1:N i repozytorium katalogów."""
import json
import sqlite3
from datetime import datetime
from pathlib import Path

from manager import MediaCatalogManager
from models import deserialize_media

DB_FILE = Path(__file__).resolve().parent / 'data' / 'cinestream.db'


def get_connection(db_path=DB_FILE):
    conn = sqlite3.connect(str(db_path))
    conn.execute('PRAGMA foreign_keys = ON;')
    conn.row_factory = sqlite3.Row
    return conn


DDL_WATCHLISTS = '''
CREATE TABLE IF NOT EXISTS watchlists (
    watchlist_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    created_at TEXT NOT NULL
);'''

DDL_MEDIA_ITEMS = '''
CREATE TABLE IF NOT EXISTS media_items (
    item_id INTEGER PRIMARY KEY AUTOINCREMENT,
    watchlist_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    year INTEGER,
    rating REAL CHECK (rating BETWEEN 1.0 AND 10.0),
    is_watched INTEGER NOT NULL DEFAULT 0 CHECK (is_watched IN (0, 1)),
    duration_min INTEGER CHECK (duration_min > 0),
    title_id INTEGER NOT NULL,
    media_type TEXT NOT NULL CHECK (media_type IN ('movie', 'series')),
    genre TEXT NOT NULL,
    platform TEXT NOT NULL,
    details_json TEXT NOT NULL,
    UNIQUE (watchlist_id, title_id),
    FOREIGN KEY (watchlist_id) REFERENCES watchlists(watchlist_id) ON DELETE CASCADE
);'''


def init_database(conn):
    with conn:
        conn.execute(DDL_WATCHLISTS)
        conn.execute(DDL_MEDIA_ITEMS)


class WatchlistRepository:
    """Jedyna warstwa wykonująca zapytania SQL dotyczące katalogu."""
    def __init__(self, conn):
        self._conn = conn

    def count_watchlists(self):
        return self._conn.execute('SELECT COUNT(*) FROM watchlists').fetchone()[0]

    def save_watchlist(self, manager, created_at=None):
        """Atomowo zapisuje katalog z wszystkimi filmami i serialami."""
        created_at = created_at or datetime.now().isoformat(timespec='seconds')
        with self._conn:
            cursor = self._conn.execute(
                'INSERT INTO watchlists (name, created_at) VALUES (?, ?)',
                (manager.name, created_at))
            watchlist_id = cursor.lastrowid
            self._insert_items(watchlist_id, manager)
        return watchlist_id

    def _insert_items(self, watchlist_id, manager):
        rows = []
        for item in manager.titles:
            data = item.to_dict()
            rows.append((watchlist_id, item.title, item.year, item.rating,
                         int(item.is_watched), item.runtime_minutes(), item.title_id,
                         data['type'], item.genre, item.platform,
                         json.dumps(data, ensure_ascii=False)))
        self._conn.executemany('''
            INSERT INTO media_items (watchlist_id, title, year, rating, is_watched,
                duration_min, title_id, media_type, genre, platform, details_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', rows)

    def replace_watchlist(self, watchlist_id, manager):
        """Zastępuje zawartość istniejącego katalogu w jednej transakcji."""
        with self._conn:
            cursor = self._conn.execute(
                'UPDATE watchlists SET name = ? WHERE watchlist_id = ?',
                (manager.name, watchlist_id))
            if cursor.rowcount == 0:
                raise ValueError('Nie znaleziono katalogu w bazie.')
            self._conn.execute('DELETE FROM media_items WHERE watchlist_id = ?', (watchlist_id,))
            self._insert_items(watchlist_id, manager)

    def load_watchlist(self, watchlist_id):
        parent = self._conn.execute(
            'SELECT watchlist_id, name, created_at FROM watchlists WHERE watchlist_id = ?',
            (watchlist_id,)).fetchone()
        if parent is None:
            raise ValueError('Nie znaleziono katalogu w bazie.')
        rows = self._conn.execute(
            'SELECT details_json FROM media_items WHERE watchlist_id = ? ORDER BY item_id',
            (watchlist_id,)).fetchall()
        titles = [deserialize_media(json.loads(row['details_json'])) for row in rows]
        return MediaCatalogManager(parent['name'], titles)

    def first_watchlist_id(self):
        row = self._conn.execute('SELECT watchlist_id FROM watchlists ORDER BY watchlist_id LIMIT 1').fetchone()
        return None if row is None else row['watchlist_id']

    def delete_watchlist(self, watchlist_id):
        with self._conn:
            return self._conn.execute(
                'DELETE FROM watchlists WHERE watchlist_id = ?', (watchlist_id,)).rowcount > 0

    def count_items(self, watchlist_id):
        return self._conn.execute(
            'SELECT COUNT(*) FROM media_items WHERE watchlist_id = ?', (watchlist_id,)).fetchone()[0]
