"""Jednorazowa, idempotentna migracja katalogu JSON do SQLite."""
import json
import shutil
from pathlib import Path
from typing import Any

from models import Movie, Series, MediaTitle, deserialize_media_title
from repository import MediaCatalogRepository

def _legacy_title_to_model(row: dict[str, Any]) -> MediaTitle:
    """Obsługuje zarówno JSON Zadania 3, jak i starszy JSON z Zadania 2."""
    if row.get("type") in ("movie", "series"):
        return deserialize_media_title(row)

    # Starszy watchlist.json nie zawierał typu, platformy ani danych reżysera.
    # Rekordy te migrujemy jako filmy, zachowując wszystkie dostępne pola.
    return Movie(
        title_id=int(row["title_id"]),
        title=str(row["title"]),
        year=int(row["year"]),
        genre=str(row.get("genre", "Nieznany")),
        platform=str(row.get("platform", "Nieznana")),
        duration_min=int(row["duration_min"]),
        director=str(row.get("director", "Nieznany")),
        theatrical_premiere=str(row.get("theatrical_premiere", f"{row['year']}-01-01")),
        is_watched=bool(row.get("is_watched", False)),
        rating=row.get("rating"),
    )

def migrate_json_to_sqlite(json_path: str | Path,
                           repository: MediaCatalogRepository) -> bool:
    """Migruje tylko wtedy, gdy tabela nadrzędna jest pusta.

    Po poprawnym COMMIT tworzy kopię .bak i przenosi plik źródłowy
    do archiwum .bak. Zwraca True, jeśli wykonano migrację.
    """
    source = Path(json_path)
    if repository.count_watchlists() != 0 or not source.exists():
        return False

    with source.open("r", encoding="utf-8") as file:
        raw: Any = json.load(file)

    if isinstance(raw, dict):
        name = str(raw.get("name", "Katalog CineStream"))
        created_at = str(raw.get("created_at", "2026-01-01T00:00:00"))
        watchlist_id = int(raw.get("watchlist_id", 1))
        raw_titles = raw.get("titles", [])
    elif isinstance(raw, list):
        name = "Katalog CineStream"
        created_at = "2026-01-01T00:00:00"
        watchlist_id = 1
        raw_titles = raw
    else:
        raise ValueError("Nieobsługiwany format pliku JSON.")

    titles = [_legacy_title_to_model(row) for row in raw_titles]
    repository.save_watchlist(name, titles, created_at, watchlist_id)

    # Archiwizacja następuje dopiero po poprawnym zapisaniu całego agregatu.
    backup = source.with_suffix(source.suffix + ".bak")
    if backup.exists():
        backup = source.with_name(source.name + ".migrated.bak")
    shutil.move(str(source), str(backup))
    return True
