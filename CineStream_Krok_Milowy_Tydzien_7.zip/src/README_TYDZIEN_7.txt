CINESTREAM – KROK MILOWY TYGODNIA 7

Wymagania z PDF-a Laboratorium 4.1 dla zespołu 1:
- relacja 1:N: watchlists -> media_items
- FOREIGN KEY z ON DELETE CASCADE
- PRAGMA foreign_keys = ON przy każdym połączeniu
- repozytorium oddzielające SQL od menu i modeli
- transakcyjny zapis agregatu
- migracja JSON -> SQLite, tylko gdy baza jest pusta
- archiwizacja JSON jako .json.bak
- test_database.py

URUCHOMIENIE:
  cd src
  python main.py

AUTOTESTY:
  cd src
  python test_database.py

MIGRACJA:
Przy pierwszym uruchomieniu aplikacji storage.py tworzy data/cinestream.db,
a następnie migration.py przenosi dane z data/watchlist.json.
Po udanej migracji plik źródłowy zostaje zarchiwizowany jako
data/watchlist.json.bak. Ponowne uruchomienie nie dubluje danych.

PLIKI:
  database.py    – połączenie, PRAGMA i DDL
  repository.py  – wszystkie operacje SQL
  migration.py   – jednorazowa migracja JSON
  storage.py     – ścieżki i inicjalizacja repozytorium
  main.py        – menu aplikacji
  services.py    – obsługa prezentacji i wejścia użytkownika
  test_database.py – testy punktu kontrolnego
  models.py      – zachowane modele z Tygodnia 3, w tym klasyfikacja HIT

Uwaga:
W schemacie zachowano wymagane kolumny z PDF-a i dodano pola techniczne
genre, platform, media_type, metadata_json, aby zachować dane i rozróżnienie
Movie/Series z poprzedniego etapu projektu.
