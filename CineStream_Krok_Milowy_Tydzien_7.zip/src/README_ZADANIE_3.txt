CineStream – Zadanie 3 / Laboratorium 3.2

Uruchomienie aplikacji:
  cd src
  python main.py

Uruchomienie autotestów:
  cd src
  python test_manager.py

Najważniejsze pliki:
  models.py       – MediaTitle(ABC), Movie, Series, rejestr typów i fabryka JSON
  manager.py      – MediaCatalogManager (logika katalogu)
  storage.py      – utworzenie i wczytanie menedżera
  services.py     – operacje prezentacyjne i formularze dodawania
  main.py         – menu CLI
  test_manager.py – autotesty Zadania 3
  SPRAWOZDANIE.md – opis architektury do sprawozdania

Dyskryminator JSON:
  "type": "movie" albo "type": "series"

Uwaga o AI Guard:
PDF opisuje wymagania i tryb pracy na sali pod nazwą „Mechanizm AI Guard”,
ale nie definiuje osobnej klasy ani algorytmu AI Guard do dodania do aplikacji.
Zaimplementowano wymagania kontraktu domenowego zespołu 1 oraz testy.
