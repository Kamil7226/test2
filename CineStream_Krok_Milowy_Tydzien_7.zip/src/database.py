"""Konfiguracja połączenia SQLite i schemat relacyjny CineStream."""
import sqlite3
from pathlib import Path

DDL_WATCHLISTS = """
CREATE TABLE IF NOT EXISTS watchlists (
    watchlist_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    created_at TEXT NOT NULL
);
"""

DDL_MEDIA_ITEMS = """
CREATE TABLE IF NOT EXISTS media_items (
    item_id INTEGER PRIMARY KEY AUTOINCREMENT,
    watchlist_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    year INTEGER NOT NULL,
    rating REAL,
    is_watched INTEGER NOT NULL DEFAULT 0 CHECK (is_watched IN (0, 1)),
    duration_min INTEGER NOT NULL CHECK (duration_min > 0),
    genre TEXT NOT NULL,
    platform TEXT NOT NULL,
    media_type TEXT NOT NULL DEFAULT 'movie' CHECK (media_type IN ('movie', 'series')),
    metadata_json TEXT NOT NULL DEFAULT '{}',
    CHECK (rating IS NULL OR rating BETWEEN 1.0 AND 10.0),
    FOREIGN KEY (watchlist_id)
        REFERENCES watchlists(watchlist_id)
        ON DELETE CASCADE
);
"""

def get_connection(db_path: str | Path = "cinestream.db") -> sqlite3.Connection:
    """Tworzy połączenie, aktywuje FK i zwraca wiersze jako sqlite3.Row."""
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.row_factory = sqlite3.Row
    return conn

def initialize_database(db_path: str | Path) -> None:
    """Tworzy wymagane tabele, jeśli jeszcze nie istnieją."""
    with get_connection(db_path) as conn:
        conn.execute(DDL_WATCHLISTS)
        conn.execute(DDL_MEDIA_ITEMS)
