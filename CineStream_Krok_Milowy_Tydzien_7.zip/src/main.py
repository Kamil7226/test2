"""Punkt wejścia CineStream – Krok Milowy Tygodnia 7 (SQLite)."""
from storage import load_repository, EXPORT_PATH, DEFAULT_WATCHLIST_ID
from validators import get_int_input
from services import display_catalog, add_movie, add_series, filter_by_genre, delete_item

def print_menu() -> None:
    print("\\n" + "=" * 48)
    print("          CINESTREAM - SQLITE")
    print("=" * 48)
    print("1. Wyświetl katalog")
    print("2. Dodaj film")
    print("3. Dodaj serial")
    print("4. Filtruj po gatunku")
    print("5. Usuń pozycję")
    print("6. Eksportuj do CSV")
    print("7. Wyjście")
    print("-" * 48)

def main() -> None:
    repository = load_repository()
    running = True
    while running:
        print_menu()
        choice = get_int_input("Wybierz opcję [1-7]: ", 1, 7)
        try:
            if choice == 1:
                display_catalog(repository, DEFAULT_WATCHLIST_ID)
            elif choice == 2:
                add_movie(repository, DEFAULT_WATCHLIST_ID)
            elif choice == 3:
                add_series(repository, DEFAULT_WATCHLIST_ID)
            elif choice == 4:
                filter_by_genre(repository, DEFAULT_WATCHLIST_ID)
            elif choice == 5:
                delete_item(repository, DEFAULT_WATCHLIST_ID)
            elif choice == 6:
                count = repository.export_csv(DEFAULT_WATCHLIST_ID, EXPORT_PATH)
                print(f"Wyeksportowano {count} pozycji do {EXPORT_PATH}.")
            elif choice == 7:
                print("Zamykanie CineStream. Dane są zapisane w SQLite.")
                running = False
        except (ValueError, TypeError, KeyError) as error:
            print(f"[Błąd] {error}")

if __name__ == "__main__":
    main()
