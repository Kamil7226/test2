"""Przykładowe dane początkowe CineStream."""
from models import Movie, Series

DEFAULT_TITLES = [
    Movie(1, "Incepcja", 2010, "Sci-Fi", "Netflix", 148, "Christopher Nolan", "2010-07-16", True, 8.8),
    Movie(2, "Skazani na Shawshank", 1994, "Dramat", "HBO Max", 142, "Frank Darabont", "1994-09-23", True, 9.3),
    Movie(3, "Interstellar", 2014, "Sci-Fi", "Disney+", 169, "Christopher Nolan", "2014-11-07", True, 8.7),
    Movie(4, "Shrek", 2001, "Animacja", "SkyShowtime", 90, "Andrew Adamson", "2001-04-22"),
    Series(5, "Przykładowy serial", 2022, "Dramat", "Netflix", 2, 8, 45),
]
