"""Autotesty modeli CineStream po Zadaniu 3."""
from models import MediaTitle, Movie, Series, deserialize_media_title


def test_abstract_class():
    try:
        MediaTitle(1, "Test", 2020, "Dramat", "Netflix")
        assert False
    except TypeError:
        pass


def test_movie_and_series_models():
    movie = Movie(1, "Incepcja", 2010, "Sci-Fi", "Netflix", 148,
                  "Christopher Nolan", "2010-07-16", True, 9.5)
    series = Series(2, "Serial", 2022, "Dramat", "HBO", 2, 8, 45)
    assert movie.calculate_playback_weight() == 148.0
    assert series.calculate_playback_weight() == 720.0
    assert movie.classification == "HIT"
    assert series.classification == "NIEOCENIONY"


def test_rating_contract():
    movie = Movie(3, "Film", 2020, "Dramat", "Netflix", 90,
                  "Reżyser", "2020-01-01")
    try:
        movie.rating = 8.0
        assert False
    except ValueError:
        pass
    movie.is_watched = True
    movie.rating = 8.0
    assert movie.rating == 8.0


def test_serialization_round_trip():
    original = Movie(4, "Film", 2021, "Sci-Fi", "Prime", 110,
                     "Reżyser", "2021-01-01", True, 9.2)
    restored = deserialize_media_title(original.to_dict())
    assert isinstance(restored, Movie)
    assert restored.to_dict() == original.to_dict()


def run_tests():
    for test in (test_abstract_class, test_movie_and_series_models,
                 test_rating_contract, test_serialization_round_trip):
        test()
        print(f"[OK] {test.__name__}")
    print("\\nWszystkie testy modeli zakończone powodzeniem.")


if __name__ == "__main__":
    run_tests()
