"""Menedżer katalogu – oddziela logikę biznesową od menu CLI."""
from __future__ import annotations

import json
import os
import tempfile
from collections import defaultdict
from pathlib import Path
from typing import Any

from models import MediaTitle, deserialize_media_title


class MediaCatalogManager:
    """Zarządza filmami i serialami bez rozpoznawania ich konkretnych typów."""

    def __init__(self, data_path: Path) -> None:
        self.data_path = Path(data_path)
        self._catalog: list[MediaTitle] = []

    @property
    def catalog(self) -> list[MediaTitle]:
        return list(self._catalog)

    def add_title(self, title: MediaTitle) -> None:
        # Kontrakt sprawdzany przez wymagane zachowanie obiektu, bez isinstance.
        if not callable(getattr(title, "calculate_playback_weight", None)):
            raise TypeError("Obiekt musi realizować kontrakt MediaTitle.")
        if any(existing.title_id == title.title_id for existing in self._catalog):
            raise ValueError("Tytuł o takim ID już istnieje.")
        self._catalog.append(title)

    def remove_title(self, title_id: int) -> bool:
        for title in self._catalog:
            if title.title_id == title_id:
                self._catalog.remove(title)
                return True
        return False

    def find_by_genre(self, genre: str) -> list[MediaTitle]:
        query = genre.casefold()
        return [title for title in self._catalog if query in title.genre.casefold()]

    def total_playback_minutes(self) -> float:
        # Polimorfizm: każda podklasa sama oblicza swój czas odtwarzania.
        return round(sum(title.calculate_playback_weight() for title in self._catalog), 2)

    def total_playback_hours(self) -> float:
        return round(self.total_playback_minutes() / 60.0, 2)

    def platform_report(self) -> dict[str, float]:
        report: defaultdict[str, float] = defaultdict(float)
        for title in self._catalog:
            report[title.platform] += title.calculate_playback_weight()
        return {platform: round(minutes, 2) for platform, minutes in sorted(report.items())}

    def save_catalog(self) -> None:
        self.data_path.parent.mkdir(parents=True, exist_ok=True)
        payload = [title.to_dict() for title in self._catalog]
        temp_name = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w", encoding="utf-8", dir=self.data_path.parent,
                prefix="catalog_tmp_", suffix=".json", delete=False
            ) as temp:
                json.dump(payload, temp, indent=4, ensure_ascii=False)
                temp.flush()
                os.fsync(temp.fileno())
                temp_name = temp.name
            os.replace(temp_name, self.data_path)
        finally:
            if temp_name and os.path.exists(temp_name):
                os.unlink(temp_name)

    def load_catalog(self) -> None:
        if not self.data_path.exists():
            self._catalog = []
            return
        with self.data_path.open("r", encoding="utf-8") as file:
            raw_data: list[dict[str, Any]] = json.load(file)
        self._catalog = [deserialize_media_title(row) for row in raw_data]

    def export_csv(self, export_path: Path) -> int:
        import csv

        export_path = Path(export_path)
        export_path.parent.mkdir(parents=True, exist_ok=True)
        rows = [title.to_dict() for title in self._catalog]
        fields = sorted({key for row in rows for key in row})
        if not fields:
            fields = ["type", "title_id", "title"]
        with export_path.open("w", newline="", encoding="utf-8-sig") as file:
            writer = csv.DictWriter(file, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
        return len(rows)
