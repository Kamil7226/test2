"""Konfiguracja ścieżek i inicjalizacja bazy dla aplikacji."""
from pathlib import Path
from database import initialize_database
from repository import MediaCatalogRepository
from migration import migrate_json_to_sqlite

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "cinestream.db"
LEGACY_JSON_PATH = DATA_DIR / "watchlist.json"
EXPORT_PATH = BASE_DIR / "exports" / "watchlist.csv"
DEFAULT_WATCHLIST_ID = 1

def load_repository() -> MediaCatalogRepository:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    initialize_database(DB_PATH)
    repository = MediaCatalogRepository(DB_PATH)
    migrate_json_to_sqlite(LEGACY_JSON_PATH, repository)
    if repository.count_watchlists() == 0:
        repository.save_watchlist("Katalog CineStream", [])
    return repository
