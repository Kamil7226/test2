# CineStream – Zadanie 3

## Diagram hierarchii klas

```text
                 MediaTitle (ABC)
                 /              \
              Movie             Series

          MediaCatalogManager
          zarządza listą MediaTitle
```

## Kontrakt domenowy
- `MediaTitle` jest klasą abstrakcyjną.
- Każdy tytuł ma wspólne pola: ID, tytuł, rok, gatunek, platformę, status obejrzenia i ocenę.
- Każda podklasa implementuje `calculate_playback_weight()`.
- Ocena jest możliwa wyłącznie dla obejrzanego tytułu i mieści się w zakresie 1–10.

## Podklasy
- `Movie`: czas trwania w minutach, reżyser, data premiery kinowej.
- `Series`: liczba sezonów, liczba odcinków na sezon, minuty na odcinek.

## Polimorfizm
`MediaCatalogManager.total_playback_minutes()` i `platform_report()` wywołują
`calculate_playback_weight()` na każdym obiekcie. Nie rozpoznają, czy obiekt
jest filmem, czy serialem. Sposób obliczenia czasu określa konkretna podklasa.

## Polimorficzna persystencja JSON
Każdy obiekt zapisuje pole `type` (`movie` albo `series`). Funkcja
`deserialize_media_title()` korzysta z `ITEM_REGISTRY`, aby odtworzyć właściwą
klasę bez łańcucha `if/elif`.

## Menedżer
`MediaCatalogManager` odpowiada za dodawanie i usuwanie tytułów, filtrowanie,
sumowanie czasu, raport platform oraz zapis i odczyt JSON. Menu CLI korzysta
z menedżera, a nie manipuluje bezpośrednio wewnętrzną listą.

## Testy
Uruchomienie: `python test_manager.py`.
Testy sprawdzają klasę abstrakcyjną, polimorfizm, raport platform, filtr,
dyskryminator JSON oraz zapis i odczyt katalogu.


## Klasyfikacja HIT
W klasie bazowej `MediaTitle` właściwość `classification` zwraca `HIT`,
gdy ocena jest większa niż 9.0, `STANDARD` dla oceny 9.0 lub niższej,
a `NIEOCENIONY`, gdy brak oceny. Właściwość `is_hit` zwraca True/False.
Obie podklasy (`Movie` i `Series`) dziedziczą tę funkcjonalność.


# Krok Milowy Tygodnia 7 – SQLite

## Schemat relacyjny
Tabela `watchlists` jest tabelą nadrzędną. `media_items` jest tabelą
podrzędną i zawiera `watchlist_id` jako klucz obcy. Relacja jest 1:N.
Klucz obcy ma `ON DELETE CASCADE`.

## Integralność
Każde połączenie powstaje przez `get_connection()`, które włącza
`PRAGMA foreign_keys = ON` i ustawia `row_factory = sqlite3.Row`.
DDL wymusza `NOT NULL`, `CHECK`, `PRIMARY KEY` i `FOREIGN KEY`.

## Repozytorium i transakcje
`MediaCatalogRepository` hermetyzuje SQL. `save_watchlist()` zapisuje
rekord nadrzędny i jego elementy w jednym bloku transakcyjnym `with conn:`.
Błąd zapisu pozycji wycofuje całą transakcję.

## Most relacyjno-obiektowy
Wyniki zapytań są obiektami `sqlite3.Row`, konwertowanymi przez `dict(row)`.
Następnie repozytorium odtwarza odpowiednią klasę `Movie` lub `Series`.

## Migracja
`migrate_json_to_sqlite()` wykonuje transfer wyłącznie wtedy, gdy tabela
`watchlists` jest pusta. Po udanym zapisie archiwizuje źródłowy JSON jako
`.json.bak`. Migracja jest idempotentna.

## Punkt kontrolny
`python test_database.py` sprawdza schemat, aktywny klucz obcy,
repozytorium, odczyt obiektów, kaskadowe usuwanie, migrację i bazę `:memory:`.
