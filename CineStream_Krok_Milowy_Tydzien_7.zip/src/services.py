"""Warstwa prezentacyjna – nie wykonuje bezpośrednio zapytań SQL."""
from manager import MediaCatalogManager  # pozostawiono dla zgodności z Zadaniem 3
from repository import MediaCatalogRepository
from models import Movie, Series

def display_catalog(repository: MediaCatalogRepository, watchlist_id: int = 1) -> None:
    aggregate = repository.get_watchlist(watchlist_id)
    if aggregate is None:
        print("Nie znaleziono listy.")
        return
    print(f"\\n--- {aggregate['name']} ---")
    if not aggregate["titles"]:
        print("Katalog jest pusty.")
        return
    for title in aggregate["titles"]:
        print(title, f"| Klasyfikacja: {title.classification}")
    total = sum(title.calculate_playback_weight() for title in aggregate["titles"])
    print(f"Łączny czas: {total:.1f} min ({total / 60:.2f} godz.)")

def add_movie(repository: MediaCatalogRepository, watchlist_id: int = 1) -> None:
    from validators import get_float_input, get_int_input, get_non_empty_string, get_yes_no
    aggregate = repository.get_watchlist(watchlist_id)
    next_id = max((x.title_id for x in aggregate["titles"]), default=0) + 1
    title = get_non_empty_string("Tytuł filmu: ")
    year = get_int_input("Rok: ", 1888, 2100)
    genre = get_non_empty_string("Gatunek: ")
    platform = get_non_empty_string("Platforma: ")
    duration = get_int_input("Czas trwania (min): ", 1, 1000)
    director = get_non_empty_string("Reżyser: ")
    premiere = get_non_empty_string("Premiera kinowa (RRRR-MM-DD): ")
    watched = get_yes_no("Czy obejrzany? (tak/nie): ")
    rating = get_float_input("Ocena 1-10: ", 1.0, 10.0) if watched else None
    movie = Movie(next_id, title, year, genre, platform, duration, director, premiere, watched, rating)
    repository.add_media_item(watchlist_id, movie)
    print("Dodano film.")

def add_series(repository: MediaCatalogRepository, watchlist_id: int = 1) -> None:
    from validators import get_float_input, get_int_input, get_non_empty_string, get_yes_no
    aggregate = repository.get_watchlist(watchlist_id)
    next_id = max((x.title_id for x in aggregate["titles"]), default=0) + 1
    title = get_non_empty_string("Tytuł serialu: ")
    year = get_int_input("Rok: ", 1888, 2100)
    genre = get_non_empty_string("Gatunek: ")
    platform = get_non_empty_string("Platforma: ")
    seasons = get_int_input("Liczba sezonów: ", 1, 100)
    episodes = get_int_input("Liczba odcinków na sezon: ", 1, 500)
    minutes = get_int_input("Minuty na odcinek: ", 1, 300)
    watched = get_yes_no("Czy obejrzany? (tak/nie): ")
    rating = get_float_input("Ocena 1-10: ", 1.0, 10.0) if watched else None
    series = Series(next_id, title, year, genre, platform, seasons, episodes, minutes, watched, rating)
    repository.add_media_item(watchlist_id, series)
    print("Dodano serial.")

def filter_by_genre(repository: MediaCatalogRepository, watchlist_id: int = 1) -> None:
    from validators import get_non_empty_string
    genre = get_non_empty_string("Podaj gatunek: ")
    results = repository.find_by_genre(watchlist_id, genre)
    if not results:
        print("Brak pozycji dla podanego gatunku.")
    else:
        for item in results:
            print(item)

def delete_item(repository: MediaCatalogRepository, watchlist_id: int = 1) -> None:
    from validators import get_int_input
    item_id = get_int_input("ID pozycji do usunięcia: ", 1)
    if repository.delete_media_item(item_id):
        print("Usunięto pozycję.")
    else:
        print("Nie znaleziono pozycji.")
