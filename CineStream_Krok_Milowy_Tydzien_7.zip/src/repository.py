"""Repozytorium – jedyne miejsce, w którym aplikacja wykonuje SQL."""
import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

from database import get_connection, initialize_database
from models import MediaTitle, Movie, Series

class MediaCatalogRepository:
    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        initialize_database(self.db_path)

    def count_watchlists(self) -> int:
        with get_connection(self.db_path) as conn:
            row = conn.execute("SELECT COUNT(*) AS amount FROM watchlists").fetchone()
            return int(row["amount"])

    def count_media_items(self) -> int:
        with get_connection(self.db_path) as conn:
            row = conn.execute("SELECT COUNT(*) AS amount FROM media_items").fetchone()
            return int(row["amount"])

    def save_watchlist(self, name: str, titles: Iterable[MediaTitle],
                       created_at: str | None = None,
                       watchlist_id: int | None = None) -> int:
        """Zapisuje listę i wszystkie pozycje w jednej transakcji."""
        created_at = created_at or datetime.now().isoformat(timespec="seconds")
        with get_connection(self.db_path) as conn:
            with conn:
                if watchlist_id is None:
                    cursor = conn.execute(
                        "INSERT INTO watchlists (name, created_at) VALUES (?, ?)",
                        (name, created_at),
                    )
                    new_watchlist_id = int(cursor.lastrowid)
                else:
                    conn.execute(
                        "INSERT INTO watchlists (watchlist_id, name, created_at) VALUES (?, ?, ?)",
                        (watchlist_id, name, created_at),
                    )
                    new_watchlist_id = watchlist_id

                for title in titles:
                    self._insert_media_item(conn, new_watchlist_id, title)
            return new_watchlist_id

    @staticmethod
    def _insert_media_item(conn: sqlite3.Connection, watchlist_id: int,
                           title: MediaTitle) -> None:
        data = title.to_dict()
        media_type = data.get("type", "movie")
        if isinstance(title, Movie):
            duration = title.duration_min
            metadata = {
                "director": title.director,
                "theatrical_premiere": title.theatrical_premiere,
            }
        elif isinstance(title, Series):
            duration = int(title.calculate_playback_weight())
            metadata = {
                "seasons": title.seasons,
                "episodes_per_season": title.episodes_per_season,
                "minutes_per_episode": title.minutes_per_episode,
            }
        else:
            raise TypeError("Repozytorium obsługuje obiekty Movie i Series.")
        conn.execute(
            """INSERT INTO media_items
               (item_id, watchlist_id, title, year, rating, is_watched,
                duration_min, genre, platform, media_type, metadata_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                title.title_id, watchlist_id, title.title, title.year,
                title.rating, int(title.is_watched), duration, title.genre,
                title.platform, media_type,
                json.dumps(metadata, ensure_ascii=False),
            ),
        )

    def add_media_item(self, watchlist_id: int, title: MediaTitle) -> None:
        with get_connection(self.db_path) as conn:
            with conn:
                self._insert_media_item(conn, watchlist_id, title)

    def get_watchlist(self, watchlist_id: int = 1) -> dict[str, Any] | None:
        """Odczytuje agregat; sqlite3.Row mapuje się do dict dla fabryk."""
        with get_connection(self.db_path) as conn:
            parent = conn.execute(
                "SELECT watchlist_id, name, created_at FROM watchlists WHERE watchlist_id = ?",
                (watchlist_id,),
            ).fetchone()
            if parent is None:
                return None
            rows = conn.execute(
                """SELECT item_id, title, year, rating, is_watched, duration_min,
                          genre, platform, media_type, metadata_json
                   FROM media_items WHERE watchlist_id = ? ORDER BY item_id""",
                (watchlist_id,),
            ).fetchall()

            titles: list[MediaTitle] = []
            for row in rows:
                record = dict(row)
                metadata = json.loads(record.pop("metadata_json"))
                media_type = record.pop("media_type")
                record["title_id"] = record.pop("item_id")
                record["is_watched"] = bool(record["is_watched"])
                if media_type == "movie":
                    payload = {
                        **record,
                        "type": "movie",
                        "director": metadata.get("director", "Nieznany"),
                        "theatrical_premiere": metadata.get(
                            "theatrical_premiere", f"{record['year']}-01-01"
                        ),
                    }
                    titles.append(Movie.from_dict(payload))
                elif media_type == "series":
                    payload = {
                        **record,
                        "type": "series",
                        **metadata,
                    }
                    titles.append(Series.from_dict(payload))
                else:
                    raise ValueError(f"Nieznany media_type: {media_type}")
            return {
                "watchlist_id": int(parent["watchlist_id"]),
                "name": parent["name"],
                "created_at": parent["created_at"],
                "titles": titles,
            }

    def list_watchlists(self) -> list[dict[str, Any]]:
        with get_connection(self.db_path) as conn:
            rows = conn.execute(
                "SELECT watchlist_id, name, created_at FROM watchlists ORDER BY watchlist_id"
            ).fetchall()
            return [dict(row) for row in rows]

    def delete_watchlist(self, watchlist_id: int) -> bool:
        with get_connection(self.db_path) as conn:
            with conn:
                cursor = conn.execute(
                    "DELETE FROM watchlists WHERE watchlist_id = ?", (watchlist_id,)
                )
                return cursor.rowcount > 0

    def delete_media_item(self, item_id: int) -> bool:
        with get_connection(self.db_path) as conn:
            with conn:
                cursor = conn.execute(
                    "DELETE FROM media_items WHERE item_id = ?", (item_id,)
                )
                return cursor.rowcount > 0

    def find_by_genre(self, watchlist_id: int, genre: str) -> list[MediaTitle]:
        aggregate = self.get_watchlist(watchlist_id)
        if aggregate is None:
            return []
        query = genre.casefold()
        return [item for item in aggregate["titles"] if query in item.genre.casefold()]

    def export_csv(self, watchlist_id: int, export_path: str | Path) -> int:
        import csv
        aggregate = self.get_watchlist(watchlist_id)
        titles = aggregate["titles"] if aggregate else []
        path = Path(export_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        rows = [title.to_dict() for title in titles]
        fields = sorted({key for row in rows for key in row})
        if not fields:
            fields = ["title_id", "title", "year"]
        with path.open("w", newline="", encoding="utf-8-sig") as file:
            writer = csv.DictWriter(file, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
        return len(rows)
